<?php
$home['copy'] = 'Felicitaciones. Usted ha instalado exitosamente CubeCart.<br/>
<br/>
Este mensaje puede ser editado con un Editor de Texto <span style=\"font-weight: bold;\"><span style=\"color: rgb(255, 0, 0);\">H</span><span style=\"color: rgb(0, 0, 255);\">T</span><span style=\"color: rgb(0, 255, 0);\">M</span><span style=\"color: rgb(255, 255, 0);\">L</span></span> y podra agregar un sorprendente contenido para vender sus productos.<br/>
<br/>
Recuerde que hay una licencia de pago para remover los creditos y derechos de copia.';
$home['enabled'] = '0';
$home['title'] = 'Bienvenido a CubeCart';
?>