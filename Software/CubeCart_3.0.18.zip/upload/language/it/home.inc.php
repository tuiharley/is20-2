<?php
$home['copy'] = 'Gratulacje. CubeCart zainstalowa�e� poprawnie.<br/>
<br/>
Tekst tej wiadomo�ci mo�na edytowa� w zintegrowanym Edytorze <span style=\"font-weight: bold;\"><span style=\"color: rgb(255, 0, 0);\">H</span><span style=\"color: rgb(0, 0, 255);\">T</span><span style=\"color: rgb(0, 255, 0);\">M</span><span style=\"color: rgb(255, 255, 0);\">L</span></span>i dowolnie zmienia� jego tre��. 
<br/>
<br/>
Prosz� pami�ta�, �e za usuni�cie zapisu o naszych prawach autorskich nale�y ui�ci� op�at� licencyjn�.';
$home['enabled'] = '0';
$home['title'] = 'Witamy w CubeCart';
?>