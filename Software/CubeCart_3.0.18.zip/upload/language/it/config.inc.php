<?php
$langName = "Italian";
$charsetIso = "iso-8859-1";
$strftime = "%A %e, %B %Y";
?>