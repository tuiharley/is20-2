<?php
$home['copy'] = 'Onneksi olkoon. Olet asentanut onnistuneesti CubeCart:in.<br/>
<br/>
T�t� viesti� voidaan editoida k�ytt�m�ll� Oikeaa <span style=\"font-weight: bold;\"><span style=\"color: rgb(255, 0, 0);\">H</span><span style=\"color: rgb(0, 0, 255);\">T</span><span style=\"color: rgb(0, 255, 0);\">M</span><span style=\"color: rgb(255, 255, 0);\">L</span></span> Teksti Editoria ja voit lis�t� sis�lt�� joka auttaa myym��n tuotteitasi.<br/>
<br/>
Muista ett� sinulla ei ole oikeutta poistaa tai muokata copyright teksti�, ellet osta ohjelman lisenssi�.';
$home['enabled'] = '0';
$home['title'] = 'Welcome to CubeCart';
?>