<?php
$home['copy'] = 'Gratulerer.Du har vellykket installert Cubcart.<br/>
<br/>
Denne meldingen kan redigeres med den utvidede <span style=\"font-weight: bold;\"><span style=\"color: rgb(255, 0, 0);\">H</span><span style=\"color: rgb(0, 0, 255);\">T</span><span style=\"color: rgb(0, 255, 0);\">M</span><span style=\"color: rgb(255, 255, 0);\">L</span></span> Tekst behandleren og du kan lage innbydene innhold som hjelper deg � selge dine produkter.
<br/>
<br/>
Vennligst husk at du m� Betale en lisensavgift for � kunne fjerne copyrighten til CubeCart.';
$home['enabled'] = '0';
$home['title'] = 'Velkommen til CubeCart'; 
?>