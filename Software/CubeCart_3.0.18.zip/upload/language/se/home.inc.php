<?php
$home['copy'] = 'Grattis. Du lyckades med att installera Cubecart V3.<br/>
<br/>
Det h�r meddelandet kan redigeras genom anv�ndandet av Rich <span style=\"font-weight: bold;\"><span style=\"color: rgb(255, 0, 0);\">H</span><span style=\"color: rgb(0, 0, 255);\">T</span><span style=\"color: rgb(0, 255, 0);\">M</span><span style=\"color: rgb(255, 255, 0);\">L</span></span> Text Editor d�r du kan l�gga till inneh�ll av livligare karakt�r vilket hj�lper dig att framst�lla dina produkter b�ttre.
<br/>
<br/>
Var v�nlig och kom ih�g att det finns en licens avgift som ska Betalas f�r att f� ta bort eller redigera v�r copyright.';
$home['enabled'] = '0';
$home['title'] = 'V�lkommen till CubeCart';
?>
