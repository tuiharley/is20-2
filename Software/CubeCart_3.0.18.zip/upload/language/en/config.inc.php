<?php
$langName = "English";
$charsetIso = "iso-8859-1";
$strftime = "%A %e, %B %Y";
?>