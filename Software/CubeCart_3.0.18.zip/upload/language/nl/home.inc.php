<?php
$home['copy'] = 'Proficiat. U hebt CubeCart succesvol ge�nstalleerd!<br/>
<br/>
Dit bericht kan bewerkt worden door de <span style=\"font-weight: bold;\"><span style=\"color: rgb(255, 0, 0);\">H</span><span style=\"color: rgb(0, 0, 255);\">T</span><span style=\"color: rgb(0, 255, 0);\">M</span><span style=\"color: rgb(255, 255, 0);\">L</span></span> texteditor te gebruiken, op die manier kan U uw producten aanbieden met een mooie gestyleerde text-layout wat zeker zal helpen om uw producten te verkopen.<br/><br/>
Vergeet aub niet dat er een licentievergoeding te betalen is om ons licentiebericht te verwijderen of aan te passen.';
$home['enabled'] = '0';
$home['title'] = 'Welkom bij CubeCart.';
?>


 

    



