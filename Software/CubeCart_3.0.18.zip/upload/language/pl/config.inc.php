<?php
$langName = "Polish";
$charsetIso = "iso-8859-2";
$strftime = "%A %e, %B %Y";
?>