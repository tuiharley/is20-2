<?php
$home['copy'] = 'Tillykke. Du har med succes installeret CubeCart.<br/>
<br/>
Du kan redigere denne besked med vores Rich <span style=\"font-weight: bold;\"><span style=\"color: rgb(255, 0, 0);\">H</span><span style=\"color: rgb(0, 0, 255);\">T</span><span style=\"color: rgb(0, 255, 0);\">M</span><span style=\"color: rgb(255, 255, 0);\">L</span></span> Text Editor og du kan tilf�je  bem�rkelsesv�rdigt indhold for at underst�tte salget af dine produkter. 
<br/>
<br/>
Bem�rk venligst at du skal indbetale et licens gebyr for at fjerne eller redigere vores copyright beskeder.';
$home['enabled'] = '0';
$home['title'] = 'Velkommen til CubeCart';
?>

