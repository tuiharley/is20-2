<?php
$home['copy'] = 'Gl�ckwunsch. Sie haben CubeCart erfolgreich installiert.<br/>
<br/>
Dieser Text kann mit dem Rich <span style=\"font-weight: bold;\"><span style=\"color: rgb(255, 0, 0);\">H</span><span style=\"color: rgb(0, 0, 255);\">T</span><span style=\"color: rgb(0, 255, 0);\">M</span><span style=\"color: rgb(255, 255, 0);\">L</span></span> Text Editor ge�ndert werden und Sie k�nnen Verkaufsf�rdernden Text hinzuf�gen.
<br/>
<br/>
Bitte beachten Sie, dass Sie eine Lizenzgeb�hr entrichten m�ssen wenn Sie unsere Copyrightverweise �ndern oder entfernen m�chten.';
$home['enabled'] = '0';
$home['title'] = 'Willkommen bei CubeCart';
?>