<?php
$home['copy'] = 'F�licitation. Vous venez d\'installer CubeCart avec succ�s.<br/>
<br/>
Ce message peut �tre �dit� par l\'editeur de Texte <span style=\"font-weight: bold;\"><span style=\"color: rgb(255, 0, 0);\">H</span><span style=\"color: rgb(0, 0, 255);\">T</span><span style=\"color: rgb(0, 255, 0);\">M</span><span style=\"color: rgb(255, 255, 0);\">L</span></span> et vous pouvez ajouter de sympatique contenu pour aider � vendre vos articles. 
<br/>
<br/>
Souvenez-vous que vous utilisez Cubecart en version gratuite, et vous devez payer une license pour enlever ou modifier les copyrights.';
$home['enabled'] = '0';
$home['title'] = 'Bienvenue sur CubeCart';
?>