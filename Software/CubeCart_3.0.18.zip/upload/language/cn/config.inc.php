<?php
$langName = "Chinese";
$charsetIso = "big5";
$strftime = "%A %e, %B %Y";
?>