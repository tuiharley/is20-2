<?php
$home['copy'] = '<Span style=\"\" bold=\"\">Parab�ns. Voc� instalou com �xito o CubeCart.<br/>
<br/>
Esta mensagem pode ser editada usando um&nbsp; <span style=\"font-weight: bold;\"><span style=\"color: rgb(255, 0, 0);\">Editor<span style=\"color: rgb(0, 255, 0);\"> </span></span><span style=\"color: rgb(0, 255, 0);\">de Texto</span> <span style=\"color: rgb(51, 102, 255);\">HTML</span><span style=\"color: rgb(255, 255, 0);\"> </span></span><span style=\"color: rgb(0, 0, 0);\">com isso, pode adicionar um conteudo espetacular que ajudara na venda dos seus produtos!</span><span style=\"font-weight: bold;\"><span style=\"color: rgb(255, 255, 0);\"><br/>
<br/>
</span></span><span style=\"color: rgb(0, 0, 0);\">Lembre-se que existe uma Licen�a a pagar para editar ou remover os Direitos de c�pia...</span><span style=\"font-weight: bold;\"><span style=\"color: rgb(255, 255, 0);\"><br/>
</span></span></span>';
$home['enabled'] = '0';
$home['title'] = 'Bem vindo a CubeCart';
?>