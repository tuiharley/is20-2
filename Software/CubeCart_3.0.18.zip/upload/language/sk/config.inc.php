<?php
$langName = "Slovakian";
$charsetIso = "windows-1250";
$strftime = "%A, %d. %B %Y";
?>