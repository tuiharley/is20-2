<?php
$home['copy'] = 'Congratulations. You have successfully installed CubeCart.<br/>
<br/>
This message can be edited using the Rich <span style=\"font-weight: bold;\"><span style=\"color: rgb(255, 0, 0);\">H</span><span style=\"color: rgb(0, 0, 255);\">T</span><span style=\"color: rgb(0, 255, 0);\">M</span><span style=\"color: rgb(255, 255, 0);\">L</span></span> Text Editor and you can add vibrant content to help sell your products. 
<br/>
<br/>
Please remember that there is a license fee to pay to remove or edit our copyright notices.';
$home['enabled'] = '0';
$home['title'] = 'Welcome to CubeCart';
?>