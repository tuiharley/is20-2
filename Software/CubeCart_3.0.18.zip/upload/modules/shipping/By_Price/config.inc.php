<?php
$module['amount'] = '4.95';
$module['level'] = '50';
$module['status'] = '1';
?>