<?php
function repeatVars(){

		return FALSE;
	
}

function fixedVars(){
	
		return FALSE;

}

function success(){
	
		return FALSE;

}

///////////////////////////
// Other Vars
////////
$formAction = "modules/gateway/Print_Order_Form/orderForm.php";
$formMethod = "post";
$formTarget = "_self";
$transfer = "auto";
?>