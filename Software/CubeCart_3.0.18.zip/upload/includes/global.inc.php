<?php
$glob['dbdatabase'] = '';
$glob['dbhost'] = '';
$glob['dbpassword'] = '';
$glob['dbprefix'] = '';
$glob['dbusername'] = '';
$glob['installed'] = '0';
$glob['rootDir'] = '';
$glob['rootRel'] = '';
$glob['storeURL'] = '';
?>