﻿FCKLang.PlaceholderBtn			= 'Aggiungi/Modifica Placeholder' ;
FCKLang.PlaceholderDlgTitle		= 'Proprietà del Placeholder' ;
FCKLang.PlaceholderDlgName		= 'Nome del Placeholder' ;
FCKLang.PlaceholderErrNoName	= 'Digitare il nome del placeholder' ;
FCKLang.PlaceholderErrNameInUse	= 'Il nome inserito è già in uso' ;
