<?php
/**
* @version		$Id: helper.php 10381 2008-06-01 03:35:53Z konlungkao $
* @package		Joomla
* @copyright	Copyright (C) 2005 - 2008 Open Source Matters. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* Joomla! is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/

// no direct access
defined('_JEXEC') or die('Restricted access');

class mod_market_indexHelper
{
    function getAds( $params )
    {
        return  ' <iframe id="marke_tindex" scrolling="no" src="http://marketdata.set.or.th/static/market/marketindex_th_TH.html"
                        width="255px" height="450px" frameborder="0" align="center"></iframe> ';
  }
}