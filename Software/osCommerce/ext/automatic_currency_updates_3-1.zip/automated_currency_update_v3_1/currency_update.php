<?php
/**
 *  Automatic Currency Update v3.0 
 * Originally by Richard Fink (masterblaster)  based on Zen Cart manual currency update
 * updated by Kuroi to include Zen Cart's currency uplift ratio
 * further updated by Kuroi to use European Central Bank reference rates  (adapted from ECB-supplied code)
 *
 * @package currencies
 * @copyright Copyright 2003-2006 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: currency_update.php 1 2008-12-16 12:47:23Z kuroi $
  */

// This describes the path from the location where you install this file to the root directory of your Zen Cart
// It is normally the only line that you will need to edit.  See readme for guidance.
DEFINE('PATH_TO_STORE_ROOT','');

// Get Zen Cart configuration data
require_once(PATH_TO_STORE_ROOT . 'includes/configure.php');
require_once(PATH_TO_STORE_ROOT . 'includes/database_tables.php');

//connet to database
$link = mysql_connect(DB_SERVER, DB_SERVER_USERNAME, DB_SERVER_PASSWORD) or die("Could not connect");

//get default currency
$currency_default = mysql_db_query(DB_DATABASE, "select configuration_value from " . TABLE_CONFIGURATION . " WHERE configuration_key='DEFAULT_CURRENCY' LIMIT 1 ", $link);
$currency_default= mysql_fetch_array($currency_default);
define('DEFAULT_CURRENCY', $currency_default[0]);
 
//get currency conversion ratio
$currency_uplift_ratio =  mysql_db_query(DB_DATABASE, "select configuration_value from " . TABLE_CONFIGURATION . " WHERE configuration_key='CURRENCY_UPLIFT_RATIO' LIMIT 1 ", $link);
$currency_uplift_ratio= mysql_fetch_array($currency_uplift_ratio);
define('CURRENCY_UPLIFT_RATIO', $currency_uplift_ratio[0]); 

// Define currency file
$XMLContent= file("http://www.ecb.europa.eu/stats/eurofxref/eurofxref-daily.xml");

$currencyArray['EUR'] = 1;
foreach ($XMLContent as $line) {
  if (ereg("currency='([[:alpha:]]+)'",$line,$currencyCode)) {
    if (ereg("rate='([[:graph:]]+)'",$line,$rate)) {
      $currencyArray[$currencyCode[1]] = (float)$rate[1];
    }
  }
}

if (sizeof($currencyArray) > 1)
{
  $currencyQuery = mysql_db_query(DB_DATABASE, "select currencies_id, code from " . TABLE_CURRENCIES . "", $link);
  while ($currency = mysql_fetch_array($currencyQuery)) {
    if ($currency['code'] == DEFAULT_CURRENCY)
    {
      $rate = 1;
    }
    else
    { 
      $rate = ($currencyArray[$currency['code']] / $currencyArray[DEFAULT_CURRENCY]) * CURRENCY_UPLIFT_RATIO;
    }
    $updateSql = "UPDATE " . TABLE_CURRENCIES . "
                  SET value = '" . $rate . "',
                      last_updated = now()
                  WHERE currencies_id = '" . $currency['currencies_id']. "'";
    mysql_db_query(DB_DATABASE, $updateSql, $link);
  }
}

mysql_close($link);
?>