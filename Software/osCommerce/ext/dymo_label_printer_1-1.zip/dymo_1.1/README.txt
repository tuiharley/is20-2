Dymo Label Printer for Zen Cart 1.3.8
Version 1.1  
Author: Scott Wilson
http://www.thatsoftwareguy.com 
Zen Forum PM swguy

No warranties expressed or implied; use at your own risk.

Waaay more help is available on 

http://www.thatsoftwareguy.com/zencart_dymo.html

History: 
1.1 04/03/2008 - Added Windows/FF support
1.0 03/07/2008 - First Release - Windows/IE only
--------------------------------------------------
Overview: 
Dymo saves you time-o! 

This contribution provides a Dymo print button on the Invoice page.  
It currently works on Windows under Internet Explorer and Firefox.  

I have tested this with the Dymo 400 Labelwriter on Vista and XP, but it should
work on Win2K as well.

You will get lots of prompts from Windows the first time you run this; 
you must accept them all to successfully print a label.  
You may have to do this a couple of times before it will work.

It's a bit tedious to get it going in Firefox.  Be patient; it does work if
you follow the instructions carefully

--------------------------------------------------

Installation Instructions: 

You must have a locally or network attached Dymo 400 to use this mod.  Please
install the latest Dymo drivers from www.dymo.com before proceeding.

0. Back up everything!  Try this in a test environment prior to installing
it on a live shop.

1. Unzip the file you have received.  

2. Copy the contents of the folder you have unzipped to 
the root directory of your shop.  

3. The next time you open an invoice in Admin->Customers->Orders->Invoice,
  you should see a Dymo icon under the Ship To Address.  Clicking this icon
  should print the Ship To label on your Dymo 400.

If you have problems, please look at this page
   http://www.thatsoftwareguy.com/zencart_dymo.html
prior to posting the forum.  

Special Instructions for FireFox: 
The instruction above work in Win/IE only.  To run this mod in FireFox,
ensure your Firefox is 2.0.0 or above, by checking Help/About Mozilla Firefox.
Then you must do the following four things: 

a) install the XPI.
b) install dymo_ff.js on the local PC where you run Firefox.  This
file does not go on the server with the rest of your cart; it goes
on your local PC.
c) modify the Zen Cart invoice scripts to use the file from (b).
d) modify your Firefox preferences as noted.

If your Dymo is network attached, you must to these steps on all the
PCs on which you want to print labels.

1. You MUST install this version of the XPI.  Earlier versions DO NOT WORK.
This is not a test!   Even the one on the Dymo site (as of Mar 08) does not
work.   

In your browser, open New_Firefox_Installer/install.htm and click the 
"Install Now" link.   Then in Firefox, under Tools/Add-ons, ensure you have
DLS SDK 1.2.0.0 (or better).

2. Put the file dymo_ff.js on your PC.  You will need to make a note of 
where this file is in the next step.  For example, mine is on my desktop,
so the path to it is c:\Users\Scott\Desktop\dymo_ff.js. 

3. Edit the files admin/invoice.php and admin/super_invoice.php.
   Comment out the line that pulls in javascript/dymo_js.php

  // require(DIR_WS_INCLUDES . 'javascript/dymo_js.php');

  then above the line that begins php (it looks like this: <?php )
  you must include your dymo_ff.js file from the previous step.  
  For Vista, mine looks like this: 

  <script src="file:///c:/Users/Scott/Desktop/dymo_ff.js">
  </script>

   For XP, mine looks like this: 

  <script src="file:///c:/Documents and Settings/Scott/Desktop/dymo_ff.js">
  </script>

  At the same time, you may want to delete 
     ./admin/includes/javascript/dymo_ie.js.php
  since you don't want to load both copies of the JS.

4. Now the fun part: modify your Firefox configuration to permit local
includes.  In the browser address bar, type about:config

   to add new entries, right click on an existing entry and say "New->String"

you must enter the three following String preferences: 

Name                                                   Value
------------------------------------------------------------------------------
capability.policy.policynames                          localfilelinks
capability.policy.localfilelinks.sites                 http://www.yourcart.com
capability.policy.localfilelinks.checkloaduri.enabled  allAccess

then you must enter the following Boolean preference: 
Name                                                   Value
------------------------------------------------------------------------------
signed.applets.codebase_principal_support              true

Obviously "yourcart.com" should be replaced with your real hostname.
Use http://www.yourcart.com/subdirectory if the cart is in a subdirectory.
Don't put a slash at the end.
To test this in a local installation, you can also use a private IP address
(e.g. "http://192.168.1.103/mystore")

You're done!  Open an invoice and print a label.  Be patient - the first one
can take up to 30 seconds.   If it doesn't work, exit 
FireFox and find your prefs.js file - for instructions see this link: 

http://kb.mozillazine.org/Profile_folder_-_Firefox

In the file, you need to see lines that look like this:
user_pref("capability.policy.policynames", "localfilelinks");
user_pref("capability.policy.localfilelinks.sites", "http://www.yourcart.com");
user_pref("capability.policy.localfilelinks.checkloaduri.enabled",
"allAccess");
...
user_pref("signed.applets.codebase_principal_support","true"); 

Check for typos, etc.  Note that this file should only be edited if you are
not in Firefox.

 
New Files
=========
./admin/includes/javascript/dymo_ie.js.php
dymo_ff.js
./admin/images/dymo.jpg
./admin/super_invoice.php   (based on ver 2.0 rev 46)

Modified Files (No Overrides)
=============================
./admin/invoice.php

Overrides
=========

External Files
============== 
./New_Firefox_Installer/dymo.xpi
./New_Firefox_Installer/install.htm

If you wish to download your own copy of the Dymo SDK, go to 
https://global.dymo.com/enUS/RNW/RNW.html

The scripts dymo_*.js.php were adapted from code written by Dymo in 
their Windows SDK.

