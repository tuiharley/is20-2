Copyright 2006 - 2007 Dennis Sayer
Encrypted Master Password v 1.1
A core file replacement for Zen Cart v1.3.7
These modifications have not been tested on any other version.
This modification is sponsored by Brand Name Batteries for Less. 
www.brandnamebatteries.com
====================
THE STANDARD DON'T SUE ME STUFF.
I take no responsibility for any lost business, money, etc. due to the use of 
this module. USE AT YOUR OWN RISK!
====================
SUGGESTED READING
http://en.wikipedia.org/wiki/Passphrase
http://en.wikipedia.org/wiki/Password
====================
BACKUP BACKUP BACKUP
1. Its wise to make a full backup (File and Database) of the store at 
   least once a month, and before making modifications.
====================
INSTALL
1. Compare the header_php.php file included with this download with the one 
   currently being used at your store. If you have made modifications to this
   file currently being used at your store, copy those modifications to this 
   new file.
2. Upload header_php.php to includes\modules\pages\login
====================
TEST
1. If you know the password for the first admin account, great. If you dont, 
   here is how to get the admin ID number you want to use. Login to your admin 
   page and go to 'Tools>Admin Settings'. The left hand column will be titled 
   "ID", Look for the number to the left of the admin account you want to use.
   Look in Features for an example on how to change the code to match the ID 
   you want to use.
2. Go to your store and enter a customer�s email address. Enter your admin 
   password as the customers password. If you get anything other than a happy 
   login, follow the instructions a second time. If it still does not work then
   post as much info as you can at 
   http://www.zen-cart.com/forum/forumdisplay.php?f=44 
   and send a PM to stagebrace.
====================
VERSION HISTORY
====================
v 1.0 (07/04/2006)
Features:
* Encrypted Master Password allows the stores administrator to login to any 
  account with there administrator password. The SLQ on line 60 can be 
  modified to change which administrator can use Encrypted Master Password.
  This example changes the Encrypted Master Password to admin #2:
  WHERE admin_id = '2' ";
-------
v 1.1 (01/16/2007)
* Added new code that appeared with Zen Cart 1.3.7
* A few wording changes in this document.
-------
v 1.2 (12/01/2007)
* Added new code that appeared with Zen Cart 1.3.8
-------
