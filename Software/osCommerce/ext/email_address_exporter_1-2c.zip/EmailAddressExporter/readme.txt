Add-On: Email Address Exporter Admin Tool v1.2c
Designed for: Zen Cart v1.2+
Created by: DrByte

Donations:  Please support ZenCart!  paypal@zen-cart.com  - Thank you!
===========================================================

NOTES:
This add-on was created to allow quick and easy exporting of 
email addresses from your Zen Cart shop.

This is especially useful if you are needing to manage mailing lists and/or send
newsletters or mass-emailings from your personal computer.
One great tool to use this with is GroupMail, which you can get a free copy of here:
http://www.shareasale.com/r.cfm?b=44610&u=151719&m=1465&urllink=&afftrack=


As to export formats, you can choose from CSV, TXT (tab-delimited), XML, or HTML formats.

You can select any of the audiences available in your cart.
The most common audience would be Newsletter recipients.

If you choose the "Save To File On Server" option, you can set the "Destination Folder"
by editing the /admin/includes/extra_datafiles/email_export.php
and set the DIR_FS_EMAIL_EXPORT to the desired destination.
The default setting (for simplicity) is the /images/uploads folder.
Whatever folder you point this to must be CHMOD 777 or equivalent so that
the webserver userid can write to files in this folder.
When saving to file, if a file of the same name already exists, it will be overwritten. No backups.

===========================================================

INSTALLATION:  
Upload all files as-is to your server, retaining folder structures.

===========================================================

USE:
To use, just log into the admin area, click on "Tools", 
and click on "Export Email Addresses".

===========================================================
$Id: email_export.php  2005-04-15  drbyte $

HISTORY:
March 10/05 - Initial Release
April 15/05 - Added XML format
May 11/05   - Added Save To File format, and tweaked streaming methods slightly
