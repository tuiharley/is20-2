<?php
define('TABLE_SET_SUBC_HEADING', 'Set subcontractors');
define('TABLE_SET_SUBC_MANUFACTURER', 'Manufacturer');
define('TABLE_SET_SUBC_MODEL', 'Model');
define('TABLE_SET_SUBC_DEFAULT', 'Default subcontractors');
define('TABLE_SET_SUBC_PRODUCTS_NAME', 'Name');
define('TABLE_SET_SUBC_LINK_PREVIOUS', 'Previous page');
define('TABLE_SET_SUBC_LINK_NEXT', 'Next page');
define('TABLE_SET_SUBC_TOTAL_FOUND', 'Found');
define('TABLE_SET_SUBC_TOTAL_OUT_OF', 'on');
define('TABLE_SET_SUBC_TOTAL_PAGES', 'pages');
?>