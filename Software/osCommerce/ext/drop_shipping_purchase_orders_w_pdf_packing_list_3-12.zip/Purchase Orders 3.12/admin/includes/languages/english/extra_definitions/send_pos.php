<?php
define('TABLE_CUSTOMER_NAME','Customer Name');
define('TABLE_ORDER_NUMBER', 'Order #');
define('TABLE_SEND_PO', 'Send PO yes/no ');
define('TABLE_PO_SUBCONTRACTOR', 'Send PO To');
define('TABLE_SHOW_DELIVERED_ORDERS', 'Show Delivered Orders');
define('TABLE_COMMENTS_FOR_POS', 'Comments for Purchase Orders');
define('TABLE_COMMENTS_FOR_PACKING_LISTS', 'Comments for Packing Lists');
define('TABLE_ADD_CUSTOMERS_COMMENTS_TO_PACKING_LIST', 'Add Customers Comments to Packing Lists');
define('TABLE_REVIEW_EMAIL_OPTION', 'Review E-mail Before Sending(Only Works Sending 1 PO at a Time)');
define('TABLE_DATA_FROM_DATES', 'Data from');
define('TABLE_SUBCONTRACTOR', 'Subcontractor');
define('TABLE_TO', 'to');
define('TABLE_SEND', 'SEND');
define('TABLE_ALL_SUBCONTRACTORS', 'All');
define('TABLE_PRODUCTS_NAME', 'Product');
define('TABLE_PO_PREOVIOUSLY_SENT_TO', 'Last Sent To');
define('TABLE_PO_PREOVIOUS_NUMBER', '2nd Part of Last PO #');
define('TABLE_PO_WHEN_SEND', 'Last Send Date');
define('BUTTON_NEW', 'View new POs');
define('BUTTON_OLD', 'View old POs and re-send them');
define('TABLE_ORDER_COMMENTS', 'Comments');
define('TABLE_ORDER_SHIPPING', 'Shipping Method');
define('TABLE_ORDER_ADDRESS', 'Shipping Address');
define('TABLE_ORDER_PRODUCT_MANUFACTURER', 'Manufacturer &amp; Model');
define('TABLE_INCLUDE_PACKINGLIST_OPTION', 'Include Packing List');
define('PACKING_LIST_FIRST_WORD', 'Packing');
define('PACKING_LIST_SECOND_WORD', 'List');
define('PACKING_LIST_MODEL_NUMBER', 'MODEL NUMBER');
define('PACKING_LIST_PRODUCT_DESCRIPTION', 'PRODUCT DESCRIPTION');
define('PACKING_LIST_QUANTITY', 'QUANTITY');
define('SHIPPING_OPTION', 'Shipping Option');
define('REVIEW_AND_SUBMIT_WARNING', 'Make sure you click the <em>SEND</em> button.  Your PO has been marked sent, but will NOT be sent unless you click <em>SEND</em>.');
define('REFRESH_WARNING', 'Warning: Never refresh this page.  Doing so may accidentaly resend purchase orders!');
define('COMMENTS_WARNING', 'Warning: The comments you add will appear on <u>every</u> purchase order or packing list you send at a time.');
define('REVIEW_EMAIL_SEND_EMAIL_TO', 'Send Email To');
define('REVIEW_EMAIL_EMAIL_TITLE', 'Email Title');

?>