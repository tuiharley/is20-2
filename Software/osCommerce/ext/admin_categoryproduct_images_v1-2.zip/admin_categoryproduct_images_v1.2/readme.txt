*Module Name:Admin Catalog Images v1.2
*Created By: inkuyo - www.inkuyo.com
*License: under the GPL - See attached License for info.
*Date: 11-0-2008
*
*
-----------------------------------------
Description
-----------------------------------------
!! Important !!

This MOD assumes you have installed Image Handler 2.

!! Important !!


This simple Mod adds category and product images to catelog view.  If no image has been assigned then a 'noimage' image is displayed.

This is conveinent for small-medium size stores that that have many unique products.  You can visually verify that images have been loaded for your products.

-----------------------------------------
Version Changes
-----------------------------------------

v1.2 - corrected directory placement
     - linked photo size to Small image Width and Height under Configuration -> Images

v1.1 - added directories
      - changed image calling to single command (DIR_WS_CATALOG_IMAGES versus DIR_WS_CATALOG . DIR_WS_IMAGES) Some systems had problems with this.

v1.0 - original

     Author: inkuyo
     Version: v1.0
     Zen Cart� Version: v1.3.7
     Update added on Nov 11, 2008


-----------------------------------------
Database Changes
-----------------------------------------

None


-----------------------------------------
EDIT - admin/includes/category_product_listing.php
-----------------------------------------


-----------------------------------------
Instructions
-----------------------------------------
Put the category_product_listing.php file in the following directory:

\admin\includes\modules\


Put noimage.gif or your own version in the \admin\images folder.

You should be able to copy over the folders.