<?php

$row_positions = array(); //must be kept global

function check_file_upload() {
	global $row_positions;

	$files = $_FILES['bulk_upload'];
	$errors = array();
	$to_insert = array();

	if ($files['error'] == 0) {
		if ($files['name'] != '') {

			$pos = strripos($files['name'],'.')+1;

			if ($extension = substr($files['name'], $pos)) {

				$allowed_extensions = array(
				'txt'
				, 'csv'
				);

				if (in_array($extension,$allowed_extensions)) {

					$path = $_SERVER['DOCUMENT_ROOT'] . '/' . $files['name'];

					if (move_uploaded_file($files['tmp_name'], $path)) {
						chmod($path, 0775);

						$lines = file($path);
						for ($i=0; $i<=count($lines); $i++) {
							$line = $lines[$i];
							$length = strlen($line);

							$line = explode(',',$line);

							if ($length) {
								if ($i != 0) {
									if (count($row_positions)) {
										//$country = $line[11]; //seans csv
										$country = trim(strtolower(get_row_id('country', $line))); //given csv

										if ($country == 'uk') {
											$country_id = 222;
										} else if ($country == 'us') {
											$country_id = 223;
										}

										$gender = strtolower(get_row_id('gender', $line));
										$gender = substr($gender, 0, 1);

										//dynamic type
										$post = array(
										'customers_gender'=>$gender
										, 'customers_firstname'=>get_row_id('first_name', $line)
										, 'customers_lastname'=>get_row_id('last_name', $line)
										, 'customers_dob'=>get_row_id('dob', $line)
										, 'customers_email_address'=>get_row_id('email', $line)
										, 'entry_company'=>get_row_id('company', $line)
										, 'entry_street_address'=>get_row_id('street_address', $line)
										, 'entry_suburb'=>get_row_id('suburb', $line)
										, 'entry_city'=>get_row_id('city', $line)
										, 'entry_state'=>convert_state(get_row_id('state', $line), 'name')
										, 'entry_postcode'=>get_row_id('postcode', $line)
										, 'entry_country_id'=>$country_id
										, 'customers_telephone'=>get_row_id('telephone', $line)
										, 'customers_fax'=>get_row_id('fax', $line)
										, 'customers_newsletter'=>(in_array(strtolower(get_row_id('newsletter', $line)), array(false,'','n','no')) ? 0:1)
										, 'send_welcome'=>(in_array(strtolower(get_row_id('send_welcome', $line)), array(false,'','n','no')) ? 0:1)
										, 'customers_authorization'=>0
										, 'customers_group_pricing'=>0
										, 'customers_referral'=>''
										, 'customers_email_format'=>'HTML'
										);

										foreach ($post as $key=>$value) {
											$_POST[$key] = $value;
										}

										$array = validate_customer();

										//echo '<pre>';
										//print_r($array);
										//print_r($line);
										//print_r($post);
										//print_r($array['errors']);
										//echo '</pre>';

										if (isset($array['errors'][0])) {
											$errors[$i] = $array['errors'];
										} else {
											$to_insert[$i] = $post;

											if ($_POST['insert_mode'] == 'part') {
												insert_customer();
											}
										}

										foreach ($post as $key=>$value) {
											unset($_POST[$key]);
										}
									} else {
										$errors[] = 'Either the header row in the input file is empty or it was not recognised: ';
										break;
									}
								} else {

									foreach ($line as $key=>$value) {
										$value = strtolower(trim($value));

										switch ($value) {
											case 'email':
												$row_positions['email'] = $key;
												break;
											case 'first_name':
												$row_positions['first_name'] = $key;
												break;
											case 'last_name':
												$row_positions['last_name'] = $key;
												break;
											case 'dob':
												$row_positions['dob'] = $key;
												break;
											case 'gender':
												$row_positions['gender'] = $key;
												break;
											case 'company':
												$row_positions['company'] = $key;
												break;
											case 'street_address':
												$row_positions['street_address'] = $key;
												break;
											case 'suburb':
												$row_positions['suburb'] = $key;
												break;
											case 'state':
												$row_positions['state'] = $key;
												break;
											case 'city':
												$row_positions['city'] = $key;
												break;
											case 'postcode':
												$row_positions['postcode'] = $key;
												break;
											case 'country':
												$row_positions['country'] = $key;
												break;
											case 'telephone':
												$row_positions['telephone'] = $key;
												break;
											case 'fax':
												$row_positions['fax'] = $key;
												break;
											case 'newsletter':
												$row_positions['newsletter'] = $key;
												break;
											case 'send_welcome':
												$row_positions['send_welcome'] = $key;
												break;
										}
									}
								}
							}
						}

						if ($_POST['insert_mode'] == 'file') {
							if (!count($errors)) {
								foreach ($to_insert as $line_no=>$post) {
									foreach ($post as $key=>$value) {
										$_POST[$key] = $value;
									}

									insert_customer();

									foreach ($post as $key=>$value) {
										unset($_POST[$key]);
									}
								}
							} else {
								$to_insert = array();
							}
						}

						unlink($path); //delete the file
					} else {
						$errors[] = 'Could not move file';
					}
				} else {
					$errors[] = 'File extension must be in: ' . implode(', ',$allowed_extensions);
				}
			}
		} else {
			$errors[] = 'Please choose a file before pressing upload';
		}
	} else {
		$errors[] = 'Error uploading file';
	}

	$return['errors'] = $errors;
	$return['feedback'] = $to_insert;

	return $return;
}

function get_row_id($field_name, $line) {
	global $row_positions;

	$return = false;
	if (isset($row_positions[$field_name])) {
		$pos = $row_positions[$field_name];
		if ($pos !== false) {
			$return = $line[$pos];
		}
	}

	return $return;
}

function convert_state($name, $to='name') {

	$states = array(
	array('name'=>'Alabama', 'abbrev'=>'AL'),
	array('name'=>'Alaska', 'abbrev'=>'AK'),
	array('name'=>'Arizona', 'abbrev'=>'AZ'),
	array('name'=>'Arkansas', 'abbrev'=>'AR'),
	array('name'=>'California', 'abbrev'=>'CA'),
	array('name'=>'Colorado', 'abbrev'=>'CO'),
	array('name'=>'Connecticut', 'abbrev'=>'CT'),
	array('name'=>'Delaware', 'abbrev'=>'DE'),
	array('name'=>'Florida', 'abbrev'=>'FL'),
	array('name'=>'Georgia', 'abbrev'=>'GA'),
	array('name'=>'Hawaii', 'abbrev'=>'HI'),
	array('name'=>'Idaho', 'abbrev'=>'ID'),
	array('name'=>'Illinois', 'abbrev'=>'IL'),
	array('name'=>'Indiana', 'abbrev'=>'IN'),
	array('name'=>'Iowa', 'abbrev'=>'IA'),
	array('name'=>'Kansas', 'abbrev'=>'KS'),
	array('name'=>'Kentucky', 'abbrev'=>'KY'),
	array('name'=>'Louisiana', 'abbrev'=>'LA'),
	array('name'=>'Maine', 'abbrev'=>'ME'),
	array('name'=>'Maryland', 'abbrev'=>'MD'),
	array('name'=>'Massachusetts', 'abbrev'=>'MA'),
	array('name'=>'Michigan', 'abbrev'=>'MI'),
	array('name'=>'Minnesota', 'abbrev'=>'MN'),
	array('name'=>'Mississippi', 'abbrev'=>'MS'),
	array('name'=>'Missouri', 'abbrev'=>'MO'),
	array('name'=>'Montana', 'abbrev'=>'MT'),
	array('name'=>'Nebraska', 'abbrev'=>'NE'),
	array('name'=>'Nevada', 'abbrev'=>'NV'),
	array('name'=>'New Hampshire', 'abbrev'=>'NH'),
	array('name'=>'New Jersey', 'abbrev'=>'NJ'),
	array('name'=>'New Mexico', 'abbrev'=>'NM'),
	array('name'=>'New York', 'abbrev'=>'NY'),
	array('name'=>'North Carolina', 'abbrev'=>'NC'),
	array('name'=>'North Dakota', 'abbrev'=>'ND'),
	array('name'=>'Ohio', 'abbrev'=>'OH'),
	array('name'=>'Oklahoma', 'abbrev'=>'OK'),
	array('name'=>'Oregon', 'abbrev'=>'OR'),
	array('name'=>'Pennsylvania', 'abbrev'=>'PA'),
	array('name'=>'Rhode Island', 'abbrev'=>'RI'),
	array('name'=>'South Carolina', 'abbrev'=>'SC'),
	array('name'=>'South Dakota', 'abbrev'=>'SD'),
	array('name'=>'Tennessee', 'abbrev'=>'TN'),
	array('name'=>'Texas', 'abbrev'=>'TX'),
	array('name'=>'Utah', 'abbrev'=>'UT'),
	array('name'=>'Vermont', 'abbrev'=>'VT'),
	array('name'=>'Virginia', 'abbrev'=>'VA'),
	array('name'=>'Washington', 'abbrev'=>'WA'),
	array('name'=>'West Virginia', 'abbrev'=>'WV'),
	array('name'=>'Wisconsin', 'abbrev'=>'WI'),
	array('name'=>'Wyoming', 'abbrev'=>'WY')
	);

	$return = trim($name);
	foreach ($states as $state) {

		foreach ($state as $title=>$value) {
			if (strtolower($value) == strtolower(trim($name))) {
				if ($to == 'name') {
					$return = $state['name'];
				} else {
					$return = $state['abbrev'];
				}
				break;
			}
		}

	}

	return $return;
}

function insert_customer() {
	global $db, $messageStack;

	$customers_password = zen_create_random_value(ENTRY_PASSWORD_MIN_LENGTH);

	$customers_firstname = zen_db_prepare_input($_POST['customers_firstname']);
	$customers_lastname = zen_db_prepare_input($_POST['customers_lastname']);
	$customers_email_address = zen_db_prepare_input($_POST['customers_email_address']);
	$customers_telephone = zen_db_prepare_input($_POST['customers_telephone']);
	$customers_fax = zen_db_prepare_input($_POST['customers_fax']);
	$customers_newsletter = zen_db_prepare_input($_POST['customers_newsletter']);
	$customers_group_pricing = (int)zen_db_prepare_input($_POST['customers_group_pricing']);
	$customers_email_format = zen_db_prepare_input($_POST['customers_email_format']);
	$customers_gender = zen_db_prepare_input($_POST['customers_gender']);
	$customers_dob = (empty($_POST['customers_dob']) ? zen_db_prepare_input('0001-01-01 00:00:00') : zen_db_prepare_input($_POST['customers_dob']));


	$customers_authorization = zen_db_prepare_input($_POST['customers_authorization']);
	$customers_referral= zen_db_prepare_input($_POST['customers_referral']);

	$send_welcome = zen_db_prepare_input($_POST['send_welcome']);

	if (CUSTOMERS_APPROVAL_AUTHORIZATION == 2 and $customers_authorization == 1) {
		$customers_authorization = 2;
		$messageStack->add_session(ERROR_CUSTOMER_APPROVAL_CORRECTION2, 'caution');
	}

	if (CUSTOMERS_APPROVAL_AUTHORIZATION == 1 and $customers_authorization == 2) {
		$customers_authorization = 1;
		$messageStack->add_session(ERROR_CUSTOMER_APPROVAL_CORRECTION1, 'caution');
	}

	$default_address_id = zen_db_prepare_input($_POST['default_address_id']);
	$entry_street_address = zen_db_prepare_input($_POST['entry_street_address']);
	$entry_suburb = zen_db_prepare_input($_POST['entry_suburb']);
	$entry_postcode = zen_db_prepare_input($_POST['entry_postcode']);
	$entry_city = zen_db_prepare_input($_POST['entry_city']);
	$entry_country_id = zen_db_prepare_input($_POST['entry_country_id']);

	$entry_company = zen_db_prepare_input($_POST['entry_company']);
	$entry_state = zen_db_prepare_input($_POST['entry_state']);

	if (isset($_POST['entry_zone_id'])) {
		$entry_zone_id = zen_db_prepare_input($_POST['entry_zone_id']);
	}

	$sql_data_array = array('customers_firstname' => $customers_firstname,
	'customers_lastname' => $customers_lastname,
	'customers_email_address' => $customers_email_address,
	'customers_telephone' => $customers_telephone,
	'customers_fax' => $customers_fax,
	'customers_group_pricing' => $customers_group_pricing,
	'customers_newsletter' => $customers_newsletter,
	'customers_email_format' => $customers_email_format,
	'customers_authorization' => $customers_authorization,
	'customers_referral' => $customers_referral,
	'customers_password' => zen_encrypt_password($customers_password),
	);

	if (ACCOUNT_GENDER == 'true') {
		$sql_data_array['customers_gender'] = $customers_gender;
	}

	if (ACCOUNT_DOB == 'true') {
		$sql_data_array['customers_dob'] = ($customers_dob == '0001-01-01 00:00:00' ? '0001-01-01 00:00:00' : zen_date_raw($customers_dob));
	}

	zen_db_perform(TABLE_CUSTOMERS, $sql_data_array);
	$customer_id = $db->Insert_ID();

	if ($entry_zone_id > 0) {
		$entry_state = '';
	}

	$sql_data_array = array('customers_id' => $customer_id,
	'entry_firstname' => $customers_firstname,
	'entry_lastname' => $customers_lastname,
	'entry_street_address' => $entry_street_address,
	'entry_postcode' => $entry_postcode,
	'entry_city' => $entry_city,
	'entry_country_id' => $entry_country_id);

	if (ACCOUNT_GENDER == 'true') {
		if (!in_array(array('m','f'), substr(strtolower($entry_gender), 0, 1))) {
			$errors[] = 'Gender not recognised. Expected "m" or "f", got: ' . $entry_gender;
		}
		$sql_data_array['entry_gender'] = $entry_gender;
	}
	
	if (ACCOUNT_COMPANY == 'true') $sql_data_array['entry_company'] = $entry_company;
	if (ACCOUNT_SUBURB == 'true') $sql_data_array['entry_suburb'] = $entry_suburb;
	if (ACCOUNT_STATE == 'true') {
		if ($entry_zone_id > 0) {
			$sql_data_array['entry_zone_id'] = $entry_zone_id;
			$sql_data_array['entry_state'] = '';
		} else {
			$sql_data_array['entry_zone_id'] = '0';
			$sql_data_array['entry_state'] = $entry_state;
		}
	}

	zen_db_perform(TABLE_ADDRESS_BOOK, $sql_data_array);

	$address_id = $db->Insert_ID();

	$sql = "update " . TABLE_CUSTOMERS . "
              set customers_default_address_id = '" . (int)$address_id . "'
              where customers_id = '" . (int)$customer_id . "'";

	$db->Execute($sql);

	$sql = "insert into " . TABLE_CUSTOMERS_INFO . "
                          (customers_info_id, customers_info_number_of_logons,
                           customers_info_date_account_created)
              values ('" . (int)$customer_id . "', '0', now())";

	$db->Execute($sql);



	// build the message content
	if($send_welcome == 'send')
	{

		$name = $customers_firstname . ' ' . $customers_lastname;

		if (ACCOUNT_GENDER == 'true') {
			if ($customers_gender == 'm') {
				$email_text = sprintf(EMAIL_GREET_MR, $customers_lastname);
			} else {
				$email_text = sprintf(EMAIL_GREET_MS, $customers_lastname);
			}
		} else {
			$email_text = sprintf(EMAIL_GREET_NONE, $customers_firstname);
		}
		$html_msg['EMAIL_GREETING'] = str_replace('\n','',$email_text);
		$html_msg['EMAIL_FIRST_NAME'] = $customers_firstname;
		$html_msg['EMAIL_LAST_NAME']  = $customers_lastname;

		// initial welcome
		$email_text .=  EMAIL_WELCOME;
		$html_msg['EMAIL_WELCOME'] = str_replace('\n','',EMAIL_WELCOME);

		if (NEW_SIGNUP_DISCOUNT_COUPON != '' and NEW_SIGNUP_DISCOUNT_COUPON != '0') {
			$coupon_id = NEW_SIGNUP_DISCOUNT_COUPON;
			$coupon = $db->Execute("select * from " . TABLE_COUPONS . " where coupon_id = '" . $coupon_id . "'");
			$coupon_desc = $db->Execute("select coupon_description from " . TABLE_COUPONS_DESCRIPTION . " where coupon_id = '" . $coupon_id . "' and language_id = '" . $_SESSION['languages_id'] . "'");
			$db->Execute("insert into " . TABLE_COUPON_EMAIL_TRACK . " (coupon_id, customer_id_sent, sent_firstname, emailed_to, date_sent) values ('" . $coupon_id ."', '0', 'Admin', '" . $email_address . "', now() )");

			// if on, add in Discount Coupon explanation
			//        $email_text .= EMAIL_COUPON_INCENTIVE_HEADER .
			$email_text .= "\n" . EMAIL_COUPON_INCENTIVE_HEADER .
			(!empty($coupon_desc->fields['coupon_description']) ? $coupon_desc->fields['coupon_description'] . "\n\n" : '') .
			strip_tags(sprintf(EMAIL_COUPON_REDEEM, ' ' . $coupon->fields['coupon_code'])) . EMAIL_SEPARATOR;
			$html_msg['COUPON_TEXT_VOUCHER_IS'] = EMAIL_COUPON_INCENTIVE_HEADER ;
			$html_msg['COUPON_DESCRIPTION']     = (!empty($coupon_desc->fields['coupon_description']) ? '<strong>' . $coupon_desc->fields['coupon_description'] . '</strong>' : '');
			$html_msg['COUPON_TEXT_TO_REDEEM']  = str_replace("\n", '', sprintf(EMAIL_COUPON_REDEEM, ''));
			$html_msg['COUPON_CODE']  = $coupon->fields['coupon_code'];
		} //endif coupon

		if (NEW_SIGNUP_GIFT_VOUCHER_AMOUNT > 0) {
			$coupon_code = zen_create_coupon_code();
			$insert_query = $db->Execute("insert into " . TABLE_COUPONS . " (coupon_code, coupon_type, coupon_amount, date_created) values ('" . $coupon_code . "', 'G', '" . NEW_SIGNUP_GIFT_VOUCHER_AMOUNT . "', now())");
			$insert_id = $db->Insert_ID();
			$db->Execute("insert into " . TABLE_COUPON_EMAIL_TRACK . " (coupon_id, customer_id_sent, sent_firstname, emailed_to, date_sent) values ('" . $insert_id ."', '0', 'Admin', '" . $email_address . "', now() )");

			// if on, add in GV explanation
			$email_text .= "\n\n" . sprintf(EMAIL_GV_INCENTIVE_HEADER, $currencies->format(NEW_SIGNUP_GIFT_VOUCHER_AMOUNT)) .
			sprintf(EMAIL_GV_REDEEM, $coupon_code) .
			EMAIL_GV_LINK . zen_href_link(FILENAME_GV_REDEEM, 'gv_no=' . $coupon_code, 'NONSSL', false) . "\n\n" .
			EMAIL_GV_LINK_OTHER . EMAIL_SEPARATOR;
			$html_msg['GV_WORTH'] = str_replace('\n','',sprintf(EMAIL_GV_INCENTIVE_HEADER, $currencies->format(NEW_SIGNUP_GIFT_VOUCHER_AMOUNT)) );
			$html_msg['GV_REDEEM'] = str_replace('\n','',str_replace('\n\n','<br />',sprintf(EMAIL_GV_REDEEM, '<strong>' . $coupon_code . '</strong>')));
			$html_msg['GV_CODE_NUM'] = $coupon_code;
			$html_msg['GV_CODE_URL'] = str_replace('\n','',EMAIL_GV_LINK . '<a href="' . zen_href_link(FILENAME_GV_REDEEM, 'gv_no=' . $coupon_code, 'NONSSL', false) . '">' . TEXT_GV_NAME . ': ' . $coupon_code . '</a>');
			$html_msg['GV_LINK_OTHER'] = EMAIL_GV_LINK_OTHER;
		} // endif voucher

		// add in regular email welcome text
		$email_text .= "\n\n" . sprintf(EMAIL_TEXT,$customers_password) . EMAIL_CONTACT . EMAIL_GV_CLOSURE;


		$html_msg['EMAIL_MESSAGE_HTML']  = str_replace('\n','',sprintf(EMAIL_TEXT,$customers_password));
		$html_msg['EMAIL_CONTACT_OWNER'] = str_replace('\n','',EMAIL_CONTACT);
		$html_msg['EMAIL_CLOSURE']       = nl2br(EMAIL_GV_CLOSURE);

		// include create-account-specific disclaimer
		$email_text .= "\n\n" . sprintf(EMAIL_DISCLAIMER_NEW_CUSTOMER, STORE_OWNER_EMAIL_ADDRESS). "\n\n";
		$html_msg['EMAIL_DISCLAIMER'] = sprintf(EMAIL_DISCLAIMER_NEW_CUSTOMER, '<a href="mailto:' . STORE_OWNER_EMAIL_ADDRESS . '">'. STORE_OWNER_EMAIL_ADDRESS .' </a>');

		// send welcome email
		zen_mail($name, $customers_email_address, EMAIL_SUBJECT, $email_text, STORE_NAME, EMAIL_FROM, $html_msg, 'welcome');

		// send additional emails
		if (SEND_EXTRA_CREATE_ACCOUNT_EMAILS_TO_STATUS == '1' and SEND_EXTRA_CREATE_ACCOUNT_EMAILS_TO !='') {


			$extra_info=email_collect_extra_info($name,$email_address, $customers_firstname . ' ' . $customers_lastname , $customers_email_address );
			$html_msg['EXTRA_INFO'] = $extra_info['HTML'];
			zen_mail('', SEND_EXTRA_CREATE_ACCOUNT_EMAILS_TO, '[ACCOUNT CREATED BY ADMINISTRATOR]' . ' ' . EMAIL_SUBJECT,$email_text . $extra_info['TEXT'], STORE_NAME, EMAIL_FROM, $html_msg, 'welcome_extra');
		} //endif send extra emails
	}
	//zen_redirect(zen_href_link(FILENAME_CUSTOMERS, '', 'NONSSL'));

}

function validate_customer() {
	global $db, $messageStack;

	$errors = array();

	$customers_password = zen_create_random_value(ENTRY_PASSWORD_MIN_LENGTH);
	$customers_firstname = zen_db_prepare_input($_POST['customers_firstname']);
	$customers_lastname = zen_db_prepare_input($_POST['customers_lastname']);
	$customers_email_address = zen_db_prepare_input($_POST['customers_email_address']);
	$customers_telephone = zen_db_prepare_input($_POST['customers_telephone']);
	$customers_fax = zen_db_prepare_input($_POST['customers_fax']);
	$customers_newsletter = zen_db_prepare_input($_POST['customers_newsletter']);
	$customers_group_pricing = (int)zen_db_prepare_input($_POST['customers_group_pricing']);
	$customers_email_format = zen_db_prepare_input($_POST['customers_email_format']);
	$customers_gender = zen_db_prepare_input($_POST['customers_gender']);
	$customers_dob = (empty($_POST['customers_dob']) ? zen_db_prepare_input('0001-01-01 00:00:00') : zen_db_prepare_input($_POST['customers_dob']));
	$customers_authorization = zen_db_prepare_input($_POST['customers_authorization']);
	$customers_referral= zen_db_prepare_input($_POST['customers_referral']);
	$send_welcome = zen_db_prepare_input($_POST['send_welcome']);

	if (CUSTOMERS_APPROVAL_AUTHORIZATION == 2 and $customers_authorization == 1) {
		$customers_authorization = 2;
		$messageStack->add_session(ERROR_CUSTOMER_APPROVAL_CORRECTION2, 'caution');
	}

	if (CUSTOMERS_APPROVAL_AUTHORIZATION == 1 and $customers_authorization == 2) {
		$customers_authorization = 1;
		$messageStack->add_session(ERROR_CUSTOMER_APPROVAL_CORRECTION1, 'caution');
	}

	$default_address_id = zen_db_prepare_input($_POST['default_address_id']);
	$entry_street_address = zen_db_prepare_input($_POST['entry_street_address']);
	$entry_suburb = zen_db_prepare_input($_POST['entry_suburb']);
	$entry_postcode = zen_db_prepare_input($_POST['entry_postcode']);
	$entry_city = zen_db_prepare_input($_POST['entry_city']);
	$entry_country_id = zen_db_prepare_input($_POST['entry_country_id']);

	$entry_company = zen_db_prepare_input($_POST['entry_company']);
	$entry_state = zen_db_prepare_input($_POST['entry_state']);

	if (isset($_POST['entry_zone_id'])) {
		$entry_zone_id = zen_db_prepare_input($_POST['entry_zone_id']);
	}

	if (strlen($entry_postcode) > 0 && strlen($customers_firstname) < ENTRY_FIRST_NAME_MIN_LENGTH) {
		$errors[] = 'First name is a required field';
	}

	if (strlen($customers_lastname) < ENTRY_LAST_NAME_MIN_LENGTH) {
		$errors[] = 'Last name is a required field';
	}

	if (ACCOUNT_DOB == 'true') {
		if (ENTRY_DOB_MIN_LENGTH >0 && strlen($customers_dob) > 0) {

			$customers_dob = str_replace('-','',$customers_dob);
			$customers_dob = str_replace('/','',$customers_dob);

			$month = (int)substr($customers_dob, 4, 2);
			$day = (int)substr($customers_dob, 6, 2);
			$year = (int)substr($customers_dob, 0, 4);

			if (!checkdate($month, $day, $year)) {
				$errors[] = 'DOB is invalid (Must be YYYYMMDD, YYYY/MM/DD or YYYY-MM-DD)';
			}
		} else {
			$customers_dob = '0001-01-01 00:00:00';
		}
	}

	if (strlen($customers_email_address) < ENTRY_EMAIL_ADDRESS_MIN_LENGTH) {
		$errors[] = 'Email is a required field';
	}

	if (!zen_validate_email($customers_email_address)) {
		$errors[] = 'Email is a not valid';
	}

	if (strlen($entry_street_address) > 0 && strlen($entry_street_address) < ENTRY_STREET_ADDRESS_MIN_LENGTH) {
		$errors[] = 'Street address is a required field';
	}
	
	if (strlen($entry_postcode) > 0 && strlen($entry_postcode) < ENTRY_POSTCODE_MIN_LENGTH) {
		$errors[] = 'Postcode is a required field';
	} else if (strlen($entry_postcode) > 0 && $entry_country_id == 223 && strlen($entry_postcode) != 5) {
		$errors[] = 'US Zip codes must be 5 numbers and no letters: ' . $entry_postcode;
	}

	if (strlen($entry_city) > 0 && strlen($entry_city) < ENTRY_CITY_MIN_LENGTH) {
		$errors[] = 'City is a required field';
	}

	if ($entry_country_id == '') {
		$errors[] = 'Country is a required field';
	}

	if (ACCOUNT_STATE == 'true') {
		if ($entry_country_id != '') {
			$zone_id = 0;
			$check_value = $db->Execute("select count(*) as total
                                         from " . TABLE_ZONES . "
                                         where zone_country_id = '" . (int)$entry_country_id . "'");

			$entry_state_has_zones = ($check_value->fields['total'] > 0);

			if ($entry_state_has_zones == true) {
				$zone_query = $db->Execute("select zone_id
                                          from " . TABLE_ZONES . "
                                          where zone_country_id = '" . (int)$entry_country_id . "'
                                          and zone_name = '" . zen_db_input($entry_state) . "'");

				if ($zone_query->RecordCount() > 0) {
					$entry_zone_id = $zone_query->fields['zone_id'];
				} else {
					$errors[] = 'Zone not recognised: ' . $entry_state;
				}
			} else {
				if ($entry_state == false) {
					$errors[] = 'No counties / zones specified for that country';
				}
			}
		}
	}

	//means that a telephone is not required but if it is given then it is subject to validation
	if (strlen($customers_telephone) > 0 && strlen($customers_telephone) < ENTRY_TELEPHONE_MIN_LENGTH) {
		$errors[] = 'Telephone Number too short. Minimum is ' . ENTRY_TELEPHONE_MIN_LENGTH . '. Entered was: ' . $customers_telephone;
	}

	if ($customers_email_address != '') {
		$check_email = $db->Execute("select customers_email_address
                                   from " . TABLE_CUSTOMERS . "
                                   where customers_email_address = '" . zen_db_input($customers_email_address) . "'
                                   and customers_id != '" . (int)$customers_id . "'");

		if ($check_email->RecordCount() > 0) {
			$errors[] = 'Customer Exists: ' . $customers_firstname . ' ' . $customers_lastname . ' ' . $customers_email_address;
		}
	} else {
		$errors[] = 'Please enter an email address';
	}

	if (count($errors)) {
		$cInfo = new objectInfo($_POST);
		$processed = true;
	} else {
		$errors = false;
	}
	
	$return = array('cInfo'=>$cInfo,'errors'=>$errors);
	return $return;
}

?>