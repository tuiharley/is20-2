<?php

require('includes/application_top.php');

require(DIR_WS_CLASSES . 'currencies.php');
$currencies = new currencies();

$action = (isset($_GET['action']) ? $_GET['action']:false);
$error = false;
$processed = false;
$cInfo = array();

require_once('add_customers_backend.php');

//for single customer insert
if ($action) {
	$array = validate_customer();
	$errors = $array['errors'];
	$cInfo = $array['cInfo'];

	if (count($errors) <= 1) {
		insert_customer();
		$feedback[] = 'Customer inserted successfully';
	}
}
//end of single customer insert

if (isset($_POST['add_customers_in_bulk'])) {
	$array = check_file_upload();

	$errors = $array['errors'];
	$feedback = $array['feedback'];
}

echo '
<!doctype html public "-//W3C//DTD HTML 4.01 Transitional//EN">
<html ' . HTML_PARAMS . '>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=' . CHARSET . '">
<title>' . TITLE . '</title>
<link rel="stylesheet" type="text/css" href="includes/stylesheet.css">
<link rel="stylesheet" type="text/css" href="includes/cssjsmenuhover.css" media="all" id="hoverJS">

<script language="javascript" src="includes/menu.js"></script>
<script language="javascript" src="includes/general.js"></script>
<script type="text/javascript">

function init()
{
	cssjsmenu(\'navbar\');
	if (document.getElementById)
	{
		var kill = document.getElementById(\'hoverJS\');
		kill.disabled = true;
	}
}

</script>

</head>

<body onLoad="init()">';

require(DIR_WS_INCLUDES . 'header.php');

if (count($errors) > 1) {
	echo "<div style=\"width: 98%; border: 2px dashed red; margin: 10px 0px 0px 5px; padding: 5px;\">";
	echo "<p style=\"font-weight: bold; color: red;\">There were errors</p>";
	echo '<ul>';

	foreach ($errors as $line_no=>$error) {
		if (is_array($error)) {

			echo "<div>
				Errors on line " . ($line_no+1) . " of the imported file
			</div>";
			echo '<ul>';
			foreach ($error as $err) {
				echo '<li style="color: red;">' . $err . '</li>';
			}
			echo '</ul>';
		} else {
			echo '<li style="color: red;">' . $error . '</li>';
		}
	}

	echo '</ul>';
	echo '</div>';
}

if (count($feedback)) {
	echo "<div style=\"width: 98%; border: 2px dashed green; margin: 10px 0px 0px 5px; padding: 5px;\">";
	echo "<p style=\"font-weight: bold; color: green;\">Customers inserted successfully</p>";
	echo '<ul>';

	foreach ($feedback as $line_no=>$feedback_msg) {
		if ($feedback_msg != '' && !is_array($feedback_msg)) {
			echo '<li style="color: green;">' . $feedback_msg . '</li>';
		} else {
			echo '<li style="color: green;">Line ' . ($line_no+1) . '</li>';
		}
	}

	echo '</ul>';
	echo '</div>';
}


$insert_mode = (isset($_POST['insert_mode']) ? $_POST['insert_mode']:'file');

echo '<table border="0" width="100%" cellspacing="2" cellpadding="2">
  <tr>
    <td width="100%" valign="top">
    	<table border="0" width="100%" cellspacing="0" cellpadding="2">';


$newsletter_array = array(array('id' => '1', 'text' => ENTRY_NEWSLETTER_YES),
array('id' => '0', 'text' => ENTRY_NEWSLETTER_NO));

echo '<tr>
        <td><table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td class="pageHeading">' . HEADING_TITLE . '</td>
            <td class="pageHeading" align="right">' . zen_draw_separator('pixel_trans.gif', HEADING_IMAGE_WIDTH, HEADING_IMAGE_HEIGHT) . '</td>
          </tr>
        </table>
        </td>
      </tr>
       <tr>
        <td>' . zen_draw_separator('pixel_trans.gif', '1', '10') . '</td>
      </tr>
      <tr>
        <td class="formAreaTitle">Bulk Upload (CSV)</td>
      </tr>
      <tr>
        <td class="formArea">
        	<form method="POST" enctype="multipart/form-data" action="' . $_SERVER['PHP_SELF'] . '">
        	<table border="0" cellspacing="2" cellpadding="2">
        		<tr>
        			<td>
        				File to import: <input type="file" name="bulk_upload" />
        			</td>
        		</tr>
        		<tr>
        			<td>
        				<div style="float:left;">Insert Mode:</div>
        				<div style="float:left;">
        					<input type="radio" name="insert_mode" value="part" ' . ($insert_mode == 'part' ? 'checked="checked"':'') . '/> Part (Insert valid lines)<br />
        					<input type="radio" name="insert_mode" value="file" ' . ($insert_mode == 'file' ? 'checked="checked"':'') . '/> File (Require whole file to be valid)
        				</div>
        			</td>
        		</tr>
        		<tr>
        			<td>
        				<div style="width:350px; text-align: right;">
        					<a href="add_customers_formatting_csv.html" target="_blank">Formatting the CSV</a>&nbsp;<input type="submit" name="add_customers_in_bulk" value="Upload" />
        				</div>
        			</td>
        		</tr>
        	</table>
        	</form>
        </td>
      </tr>

      <tr>
        <td>' . zen_draw_separator('pixel_trans.gif', '1', '10') . '</td>
      </tr>';

if (!isset($_POST['add_customers_in_bulk'])) {

	echo '<tr>
      			<form method="POST" action="add_customers.php?action=add_complete">
        		<td class="formAreaTitle">' . CATEGORY_PERSONAL . '</td>
      		</tr>
      		<tr>
        		<td class="formArea"><table border="0" cellspacing="2" cellpadding="2">';

	if (ACCOUNT_GENDER == 'true') {

		echo '<tr>
            <td class="main" style="vertical-align:top;">' . ENTRY_GENDER . '</td>
            <td class="main">
            	<input type="radio" name="customers_gender" value="m" ' . ($cInfo->customers_gender == 'm' ? 'checked':false) . ' /> Male<br/>
            	<input type="radio" name="customers_gender" value="f" ' . ($cInfo->customers_gender == 'f' ? 'checked':false) . ' /> Female
			</td>
          </tr>';
	}

	$customers_authorization_array = array(array('id' => '0', 'text' => CUSTOMERS_AUTHORIZATION_0),
	array('id' => '1', 'text' => CUSTOMERS_AUTHORIZATION_1),
	array('id' => '2', 'text' => CUSTOMERS_AUTHORIZATION_2),
	array('id' => '3', 'text' => CUSTOMERS_AUTHORIZATION_3)
	);

	echo '<tr>
            <td class="main">' . CUSTOMERS_AUTHORIZATION . '</td>
            <td class="main">';

	echo zen_draw_pull_down_menu('customers_authorization', $customers_authorization_array, $cInfo->customers_authorization);

	echo '	</td>
          </tr>
          <tr>
            <td class="main">' . ENTRY_FIRST_NAME . '</td>
            <td class="main">
            	<input size="30" name="customers_firstname" value="' . $cInfo->customers_firstname . '" />
			</td>
          </tr>';

	echo '</td>
          </tr>
          <tr>
            <td class="main">' .ENTRY_LAST_NAME . '</td>
            <td class="main">
              	<input size="30" name="customers_lastname" value="' . $cInfo->customers_lastname . '" />
			</td>
          </tr>';

	if (ACCOUNT_DOB == 'true') {

		echo '<tr>
				<td class="main">' . ENTRY_DATE_OF_BIRTH . '</td>
				<td class="main">
					<input size="30" name="customers_dob" value="' . $cInfo->customers_dob . '" />
				</td>
			</tr>';
	}

	echo '<tr>
			<td class="main">' . ENTRY_EMAIL_ADDRESS . '</td>
			<td class="main">
				<input size="30" name="customers_email_address" value="' . $cInfo->customers_email_address . '" />
			</td>
		</tr>';

	echo "</td>
          </tr>
        </table></td>
      </tr>";

	if (ACCOUNT_COMPANY == 'true') {
		echo '<tr>
		        <td>' . zen_draw_separator('pixel_trans.gif', '1', '10') . '</td>
		      </tr>
		      <tr>
		        <td class="formAreaTitle">' . CATEGORY_COMPANY . '</td>
		      </tr>
		      <tr>
		        <td class="formArea"><table border="0" cellspacing="2" cellpadding="2">
		          <tr>
		            <td class="main">' . ENTRY_COMPANY . '</td>
		            <td class="main">
						<input size="30" name="entry_company" value="' . $cInfo->entry_company . '" />
					</td>
				</tr>
				</table></td>
		      </tr>';
	}

	echo '		<tr>
        			<td>' . zen_draw_separator('pixel_trans.gif', '1', '10') . '</td>
      			</tr>
      			<tr>
        			<td class="formAreaTitle">' . CATEGORY_ADDRESS . '</td>
      			</tr>
      			<tr>
        			<td class="formArea"><table border="0" cellspacing="2" cellpadding="2">
          		<tr>
            		<td class="main">' . ENTRY_STREET_ADDRESS . '</td>
            		<td class="main">
<input size="30" name="entry_street_address" value="' . $cInfo->entry_street_address . '" />
					</td>
				</tr>';            

	if (ACCOUNT_SUBURB == 'true') {

		echo '<tr>
            <td class="main">' . ENTRY_SUBURB . '</td>
            <td class="main">
				<input size="30" name="entry_suburb" value="' . $cInfo->entry_suburb . '" />
			</td>
		</tr>';                        
	}

	echo '	<tr>
            <td class="main">' . ENTRY_CITY . '</td>
            <td class="main">
				<input size="30" name="entry_city" value="' . $cInfo->entry_city . '" />
			</td>
		</tr>';                                    

	if (ACCOUNT_STATE == 'true') {

		echo '<tr>
            <td class="main">' . ENTRY_STATE . '</td>
            <td class="main">';

		$entry_state = zen_get_zone_name($cInfo->entry_country_id, $cInfo->entry_zone_id, $cInfo->entry_state);

		echo zen_draw_input_field('entry_state', zen_get_zone_name($cInfo->entry_country_id, $cInfo->entry_zone_id, $cInfo->entry_state)).'(Full Name)';
	}

	echo '</td>
         </tr>
          <tr>
            <td class="main">' . ENTRY_POST_CODE . '</td>
            <td class="main">
				<input size="30" name="entry_postcode" value="' . $cInfo->entry_postcode . '" />
			</td>
		</tr>
          <tr>
            <td class="main">' . ENTRY_COUNTRY . '</td>
            <td class="main">';

	echo zen_draw_pull_down_menu('entry_country_id', zen_get_countries(), $cInfo->entry_country_id);

	echo '</td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td>' . zen_draw_separator('pixel_trans.gif', '1', '10') . '</td>
      </tr>
      <tr>
        <td class="formAreaTitle">' . CATEGORY_CONTACT . '</td>
      </tr>
      <tr>
        <td class="formArea"><table border="0" cellspacing="2" cellpadding="2">
          <tr>
            <td class="main">' . ENTRY_TELEPHONE_NUMBER . '</td>
            <td class="main">
				<input size="30" name="customers_telephone" value="' . $cInfo->customers_telephone . '" />
			</td>
		</tr>
          <tr>
            <td class="main">' . ENTRY_FAX_NUMBER . '</td>
            <td class="main">
				<input size="30" name="customers_fax" value="' . $cInfo->customers_fax . '" />
			</td>
		</tr>
        </table></td>
      </tr>
      <tr>
        <td>' . zen_draw_separator('pixel_trans.gif', '1', '10') . '</td>
      </tr>
      <tr>
        <td class="formAreaTitle">' . CATEGORY_OPTIONS . '</td>
      </tr>
      <tr>
        <td class="formArea"><table border="0" cellspacing="2" cellpadding="2">

      <tr>
        <td class="main">' . ENTRY_EMAIL_PREFERENCE . '</td>
        <td class="main">';

	$email_pref_text = ($cInfo->customers_email_format == 'TEXT') ? true : false;
	$email_pref_html = !$email_pref_text;
	echo zen_draw_radio_field('customers_email_format', 'HTML', $email_pref_html) . '&nbsp;' . ENTRY_EMAIL_HTML_DISPLAY . '&nbsp;&nbsp;&nbsp;' . zen_draw_radio_field('customers_email_format', 'TEXT', $email_pref_text) . '&nbsp;' . ENTRY_EMAIL_TEXT_DISPLAY ;

	echo '</td>
      </tr>
          <tr>
            <td class="main">' . ENTRY_NEWSLETTER . '</td>
            <td class="main">';

	echo zen_draw_pull_down_menu('customers_newsletter', $newsletter_array, (($cInfo->customers_newsletter == '1') ? '1' : '0'));

	echo '</td>
          </tr>
          <tr>
            <td class="main">' . ENTRY_PRICING_GROUP . '</td>
            <td class="main">';

	$group_array_query = $db->execute("select group_id, group_name, group_percentage from " . TABLE_GROUP_PRICING);
	$group_array[] = array('id'=>0, 'text'=>TEXT_NONE);

	while (!$group_array_query->EOF) {
		$group_array[] = array('id'=>$group_array_query->fields['group_id'], 'text'=>$group_array_query->fields['group_name'].'&nbsp;'.$group_array_query->fields['group_percentage'].'%');
		$group_array_query->MoveNext();
	}

	echo zen_draw_pull_down_menu('customers_group_pricing', $group_array, $cInfo->customers_group_pricing);

	echo '</td>
          </tr>

          <tr>
            <td class="main">' . CUSTOMERS_REFERRAL . '</td>
            <td class="main">' . 
	zen_draw_input_field('customers_referral', $cInfo->customers_referral, zen_set_field_length(TABLE_CUSTOMERS, 'customers_referral', 15)) . '
            </td>
          </tr>
        </table></td>
      </tr>
	   <tr>
        <td>' . zen_draw_separator('pixel_trans.gif', '1', '10') . '</td>
      </tr>
	   <tr>
        <td class="formAreaTitle">' . CATEGORY_EMAIL . '</td>
      </tr>
      <tr>
        <td class="formArea"><table border="0" cellspacing="2" cellpadding="2">
          <tr>
            <td class="main">' . ENTRY_EMAIL . '</td>
            <td class="main">		
			<input type="checkbox" id="send_welcome" value="send" name="send_welcome" />
			</td>
          </tr>
		</table>
		</td>
		</tr>
      <tr>
        <td>' . zen_draw_separator('pixel_trans.gif', '1', '10') . '</td>
      </tr>
      <tr>
        <td align="right" class="main">' . zen_image_submit('button_insert.gif', IMAGE_UPDATE) . ' <a href="' . zen_href_link(FILENAME_CUSTOMERS, zen_get_all_get_params(array('action')), 'NONSSL') .'">' . zen_image_button('button_cancel.gif', IMAGE_CANCEL) . '</a></td>
      </tr></form>';
} else {
	echo '	<tr>
	<td>
	<ul>
	<li>
	<a href="add_customers.php">Click here to see the Single Customer form</a>
	</li>
	</ul>
	</td>
	</tr>';
}

echo '</table></td>
  </tr>
</table>';

require(DIR_WS_INCLUDES . 'footer.php');

echo '<br>
</body>
</html>';

require(DIR_WS_INCLUDES . 'application_bottom.php');
?>