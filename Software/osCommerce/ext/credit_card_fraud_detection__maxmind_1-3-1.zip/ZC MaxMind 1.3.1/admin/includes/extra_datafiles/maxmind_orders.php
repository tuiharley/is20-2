<?php
//
// +----------------------------------------------------------------------+
// |MaxMind CCFD Module for Zen-Cart Open Source E-commerce               |
// +----------------------------------------------------------------------+
// | This source file is subject to version 2.0 of the GPL license.       |
// +----------------------------------------------------------------------+
//  $Id: maxmind_orders.php 1.2 2007-01-05 2306:15:39Z ses707 $
//
  define('FILENAME_MAXMIND_ORDERS', 'maxmind_orders.php');
  define('FILENAME_MAXMIND_UPDATE', 'maxmind_update.php');
  define('BOX_MAXMIND_ORDERS', 'MaxMind Orders');
  define('TABLE_ORDERS_MAXMIND', DB_PREFIX . 'orders_maxmind');
  define('DIR_WS_FLAGS', 'images/flags/');
?>