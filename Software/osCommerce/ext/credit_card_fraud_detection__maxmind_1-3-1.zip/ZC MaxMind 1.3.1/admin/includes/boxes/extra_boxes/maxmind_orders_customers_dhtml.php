<?php
//
// +----------------------------------------------------------------------+
// |MaxMind CCFD Module for Zen-Cart Open Source E-commerce               |
// +----------------------------------------------------------------------+
// | This source file is subject to version 2.0 of the GPL license.       |
// +----------------------------------------------------------------------+
//  $Id: maxmind_orders_customers_dhtml.php 1.2 2007-01-05 23:03:39Z ses707 $
//
  $za_contents[] = array('text' => BOX_MAXMIND_ORDERS, 'link' => zen_href_link(FILENAME_MAXMIND_ORDERS, '', 'SSL'));
?>