<?php
//
// +----------------------------------------------------------------------+
// |MaxMind CCFD Module for Zen-Cart Open Source E-commerce               |
// +----------------------------------------------------------------------+
// | This source file is subject to version 2.0 of the GPL license.       |
// +----------------------------------------------------------------------+
//  $Id: maxmind_orders.php 1.3 2007-01-05 23:07:39Z ses707 $
//

define('MODULE_PAYMENT_CC_TEXT_CREDIT_CARD_BIN_NAME', 'Credit Card Company: ');
define('MODULE_PAYMENT_CC_TEXT_CREDIT_CARD_BIN_PHONE', 'Credit Card Customer Service Phone Number: ');

?>