<?php
//
// +----------------------------------------------------------------------+
// |MaxMind CCFD Module for Zen-Cart Open Source E-commerce               |
// +----------------------------------------------------------------------+
// | This source file is subject to version 2.0 of the GPL license.       |
// +----------------------------------------------------------------------+
//  $Id: maxmind_orders.php 1.3 2007-01-05 23:20:39Z ses707 $
//
define('TABLE_ORDERS_MAXMIND', DB_PREFIX . 'orders_maxmind');
?>