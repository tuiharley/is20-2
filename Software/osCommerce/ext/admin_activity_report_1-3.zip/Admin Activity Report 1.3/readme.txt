Name
====
Admin Activity Report

Version Date
============
1.3 12.07.2008

Author
======
Steven300

Description
===========
Whenever you visit a page in admin, an activity is logged in a database table.

Such data can prove useful when trying to determine who has been altering what,
as well as making sure that your admin area hasn't been compromised.

Until now, any lookup had to be done directly from the database using a
utility like phpMyAdmin. With this contribution, you can quickly and easily
view this data within your admin area, in a nicely presented format.

Features include:
1. Ability to empty the database table's data
2. Highlights any visits to the login page from an unknown IP address.

Installation is simple with only 7 new files. No database modification.
No overwriting or overriding of files.

For support/feedback, search the forum for "Admin Activity Report [support thread]"


Affected files
==============
Changed files
-------------
- none -

New files
---------
admin/stats_admin_activity.php
admin/stats_admin_activity_all.php
admin/includes/extra_datafiles/admin_activity.php
admin/includes/boxes/extra_boxes/stats_admin_activity_reports_dhtml.php
admin/includes/languages/english/stats_admin_activity.php
admin/includes/languages/english/stats_admin_activity_all.php
admin/includes/languages/english/extra_definitions/stats_admin_activity.php


Affects DB
==========
- none -


Install
=======
0. BACKUP! BACKUP! BACKUP! BACKUP! BACKUP! BACKUP!
1. Upload all files in the admin folder
2. Go to Admin->Reports->Admin Activity

Upgrade
=======
(See Install)


Uninstall
=========
Delete these files:
admin/stats_admin_activity.php
admin/stats_admin_activity_all.php
admin/includes/extra_datafiles/admin_activity.php
admin/includes/boxes/extra_boxes/stats_admin_activity_reports_dhtml.php
admin/includes/languages/english/stats_admin_activity.php
admin/includes/languages/english/stats_admin_activity_all.php
admin/includes/languages/english/extra_definitions/stats_admin_activity.php

History
=======
1. Initial version 		1.0 		01.06.2008
2. Fixes minor bug 		1.0.1 		01.06.2008
3. Fixes db prefix issue 	1.2		28.06.2008
4. Fixes register globals bug	1.3		12.07.2008


DISCLAIMER
==========
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
(LICENSE) along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

Installation of this contribution is done at your own risk.
Backup your Zen Cart database and any and all applicable files before proceeding.