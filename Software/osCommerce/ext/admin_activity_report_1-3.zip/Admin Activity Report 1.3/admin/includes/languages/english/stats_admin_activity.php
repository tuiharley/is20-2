<?php
/**
 * Admin Activity Report
 * Version 1.3
 * By Steven300
 * @copyright Portions Copyright 2004-2008 Zen Cart Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 */

define('HEADING_TITLE', 'Admin Activity Report');

define('TEXT_INFO_ADMIN_ACTIVITY_LOG', 'Empty Admin Activity Log table from the database<br /><strong>WARNING: Be sure to backup your database before running this update!</strong>');

define('SUCCESS_CLEAN_ADMIN_ACTIVITY_LOG', '<strong>Successful</strong> Update of the Admin Activity log');

?>