<?php
/**
 * Admin Activity Report
 * Version 1.3
 * By Steven300
 * @copyright Portions Copyright 2004-2008 Zen Cart Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 */
?>
<?php
  $za_contents[] = array('text' => BOX_STATS_ADMIN_ACTIVITY, 'link' => zen_href_link(FILENAME_STATS_ADMIN_ACTIVITY, '', 'NONSSL'));
?>
