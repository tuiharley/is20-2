<?php
/**
 * Admin Activity Report
 * Version 1.3
 * By Steven300
 * @copyright Portions Copyright 2004-2008 Zen Cart Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 */

  require('includes/application_top.php');

// added by Jinson on 12th July 2008. Because this script was
// originally written expecting register globals to be on
$action = $_GET['action'];

switch($action) {

// clean out the admin_activity_log
    case 'clean_admin_activity_log':
      $db->Execute("delete from " . TABLE_ADMIN_ACTIVITY);
      $db->Execute("optimize table " . TABLE_ADMIN_ACTIVITY);
      $messageStack->add_session(SUCCESS_CLEAN_ADMIN_ACTIVITY_LOG, 'success');
      unset($_SESSION['reset_admin_activity_log']);
      zen_redirect(zen_href_link(stats_admin_activity));
    break;
    } // eof: action

unset($action);

?>
<!doctype html public "-//W3C//DTD HTML 4.01 Transitional//EN">
<html <?php echo HTML_PARAMS; ?>>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo CHARSET; ?>">
<title><?php echo TITLE; ?></title>
<link rel="stylesheet" type="text/css" href="includes/stylesheet.css">
<link rel="stylesheet" type="text/css" href="includes/cssjsmenuhover.css" media="all" id="hoverJS">
<script language="javascript" src="includes/menu.js"></script>
<script language="javascript" src="includes/general.js"></script>
<script type="text/javascript">
  <!--
  function init()
  {
    cssjsmenu('navbar');
    if (document.getElementById)
    {
      var kill = document.getElementById('hoverJS');
      kill.disabled = true;
    }
  }
  // -->
</script>
</head>
<body onload="init()">
<!-- header //-->
<?php require(DIR_WS_INCLUDES . 'header.php'); ?>
<!-- header_eof //-->

<!-- body //-->

<!-- body_text //-->

<div align=center>

<table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
		<td align=center class="pageHeading" align="center"><?php echo zen_draw_separator('pixel_trans.gif', HEADING_IMAGE_WIDTH, HEADING_IMAGE_HEIGHT); ?></td>
            <td align=center class="pageHeading"><?php echo HEADING_TITLE; ?></td>
     		<td align=center class="pageHeading" align="center"><?php echo zen_draw_separator('pixel_trans.gif', HEADING_IMAGE_WIDTH, HEADING_IMAGE_HEIGHT); ?></td>
          </tr>
        </table>


<!-- bof: reset admin_activity_log -->
      <table border="0" cellspacing="0" cellpadding="2">
          <tr>
            <td align=center class=<?php echo ($_SESSION['reset_admin_activity_log'] == true ? "alert" : "main"); ?> align="left" valign="top"><?php echo TEXT_INFO_ADMIN_ACTIVITY_LOG; ?></td>
		</tr>
		<tr>            
		<td align=center class="main" align="right" valign="middle"><?php echo '<a href="' . zen_href_link(stats_admin_activity, 'action=clean_admin_activity_log') . '">' . zen_image_button('button_reset.gif', IMAGE_RESET) . '</a>'; ?></td>
          </tr>
        </table>
<!-- eof: reset admin_activity_log -->

<br>

<?php

global $db;


$result = $db->Execute("SELECT access_date, admin_id, page_accessed, ip_address FROM " . TABLE_ADMIN_ACTIVITY . " ORDER BY access_date DESC LIMIT 20");

echo ( "<table border=1 cellspacing=2 cellpadding=2>" );

echo ( "<tr>" );

echo ( "<th>Access Date</th>" );
echo ( "<th>Admin ID</th>" );
echo ( "<th>Page Accessed</th>" );
echo ( "<th>IP Address</th>" );

echo ( "</tr>" );

$counter=0;

$check=0;
$ip="begin";

while(!$result->EOF)
{

if ($check==0) {
$ip=$result->fields['ip_address'];
$check=1;
}

if ( ( $result->fields['admin_id']==0 ) && ( $result->fields['ip_address']!=$ip ) ) {

echo ( "<td bgcolor=red align=center>" );
echo $result->fields['access_date'];
echo ( "</td>" );

echo ( "<td bgcolor=red align=center>" );
echo $result->fields['admin_id'];
echo ( "</td>" );

echo ( "<td bgcolor=red align=center>" );
echo $result->fields['page_accessed'];
echo ( "</td>" );

echo ( "<td bgcolor=red align=center>" );
echo $result->fields['ip_address'];
echo ( "</td>" );

echo ( "<tr>" );

} else {

echo ( "<td align=center>" );
echo $result->fields['access_date'];
echo ( "</td>" );

echo ( "<td align=center>" );
echo $result->fields['admin_id'];
echo ( "</td>" );

echo ( "<td align=center>" );
echo $result->fields['page_accessed'];
echo ( "</td>" );

echo ( "<td align=center>" );
echo $result->fields['ip_address'];
echo ( "</td>" );

echo ( "<tr>" );

}

$counter++;

$result->MoveNext();
}

echo ( "</table>" );

?>

<?php

if ($counter>=20) {
?>
Results 1-20 Showing. <a href="<?php echo zen_href_link(stats_admin_activity_all, 'page=stats_admin_activity_all') ?>">Show All</a>
<?php
} else {
echo ( "" );
}
?>

</div>

<!-- footer //-->
<?php require(DIR_WS_INCLUDES . 'footer.php'); ?>
<!-- footer_eof //-->
</body>
</html>
<?php require(DIR_WS_INCLUDES . 'application_bottom.php'); ?>