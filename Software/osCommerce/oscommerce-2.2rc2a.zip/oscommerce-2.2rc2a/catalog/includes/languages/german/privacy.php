<?php
/*
  $Id: privacy.php 1739 2007-12-20 00:52:16Z hpdl $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Privatsph&auml;re und Datenschutz');
define('HEADING_TITLE', 'Privatsph&auml;re und Datenschutz');

define('TEXT_INFORMATION', 'F&uuml;gen Sie hier Ihre Informationen &uuml;ber Privatsph&auml;re und Datenschutz ein.');
?>