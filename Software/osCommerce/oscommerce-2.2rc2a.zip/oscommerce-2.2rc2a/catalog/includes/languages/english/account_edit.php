<?php
/*
  $Id: account_edit.php 1739 2007-12-20 00:52:16Z hpdl $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'My Account');
define('NAVBAR_TITLE_2', 'Edit Account');

define('HEADING_TITLE', 'My Account Information');

define('MY_ACCOUNT_TITLE', 'My Account');

define('SUCCESS_ACCOUNT_UPDATED', 'Your account has been successfully updated.');
?>
