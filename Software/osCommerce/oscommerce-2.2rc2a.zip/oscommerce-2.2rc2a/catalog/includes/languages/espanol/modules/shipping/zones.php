<?php
/*
  $Id: zones.php 1739 2007-12-20 00:52:16Z hpdl $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_SHIPPING_ZONES_TEXT_TITLE', 'Tarifa por Zona');
define('MODULE_SHIPPING_ZONES_TEXT_DESCRIPTION', 'Tarifa basada en Zonas');
define('MODULE_SHIPPING_ZONES_TEXT_WAY', 'Enviar A');
define('MODULE_SHIPPING_ZONES_TEXT_UNITS', 'kg(s)');
define('MODULE_SHIPPING_ZONES_INVALID_ZONE', 'No hay envio disponible para ese pais.');
define('MODULE_SHIPPING_ZONES_UNDEFINED_RATE', 'No se han podido calcular los gastos de envio');
?>
