<?php
/*
  $Id: paypal_direct.php 1801 2008-01-11 16:49:20Z hpdl $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2008 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_PAYMENT_PAYPAL_DIRECT_TEXT_TITLE', 'PayPal Website Payments Pro (US) Direct Payments');
  define('MODULE_PAYMENT_PAYPAL_DIRECT_TEXT_PUBLIC_TITLE', 'Tarjeta de Cr&eacute;dito or tarjeta del banco (procesado con seguridad de PayPal)');
  define('MODULE_PAYMENT_PAYPAL_DIRECT_TEXT_DESCRIPTION', '<b>Attencion: PayPal necesita el PayPal Express Checkout M&oacute;dulo de Pago cuando este M&oacute;dulo esta instalado.</b><br /><br /><img src="images/icon_popup.gif" border="0">&nbsp;<a href="https://www.paypal.com/mrb/pal=PS2X9Q773CKG4" target="_blank" style="text-decoration: underline; font-weight: bold;">Visita la web de PayPal</a>&nbsp;<a href="javascript:toggleDivBlock(\'paypalDirectInfo\');">(info)</a><span id="paypalDirectInfo" style="display: none;"><br><i>Con el uso del Link para usar PayPal osCommerce dar a cada Cliente nuevo un pequeno Bonus.</i></span>');
  define('MODULE_PAYMENT_PAYPAL_DIRECT_CARD_OWNER', 'Titular de la tarjeta:');
  define('MODULE_PAYMENT_PAYPAL_DIRECT_CARD_TYPE', 'Tipo de tarjeta:');
  define('MODULE_PAYMENT_PAYPAL_DIRECT_CARD_NUMBER', 'N&uacute;mero de tarjeta:');
  define('MODULE_PAYMENT_PAYPAL_DIRECT_CARD_VALID_FROM', 'Tarjeta valida desde:');
  define('MODULE_PAYMENT_PAYPAL_DIRECT_CARD_VALID_FROM_INFO', '(si est&aacute; disponible)');
  define('MODULE_PAYMENT_PAYPAL_DIRECT_CARD_EXPIRES', 'Fecha de caducidad:');
  define('MODULE_PAYMENT_PAYPAL_DIRECT_CARD_CVC', 'C&oacute;digo de seguridad:');
  define('MODULE_PAYMENT_PAYPAL_DIRECT_CARD_ISSUE_NUMBER', 'Issue n&uacute;mero de tarjeta:');
  define('MODULE_PAYMENT_PAYPAL_DIRECT_CARD_ISSUE_NUMBER_INFO', '(es solo para tarjeta de Maestro y Solo)');
  define('MODULE_PAYMENT_PAYPAL_DIRECT_ERROR_ALL_FIELDS_REQUIRED', 'Error: Todos los datos son obligatorios.');
?>
