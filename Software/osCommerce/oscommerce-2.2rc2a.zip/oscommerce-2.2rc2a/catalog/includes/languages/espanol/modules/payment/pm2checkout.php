<?php
/*
  $Id: pm2checkout.php 1793 2008-01-11 13:48:20Z hpdl $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2008 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_PAYMENT_2CHECKOUT_TEXT_TITLE', '2Checkout');
  define('MODULE_PAYMENT_2CHECKOUT_TEXT_PUBLIC_TITLE', '2Checkout');
  define('MODULE_PAYMENT_2CHECKOUT_TEXT_PUBLIC_DESCRIPTION', 'Tarjeta de Cr&eacute;dito or Alternativas');
  define('MODULE_PAYMENT_2CHECKOUT_TEXT_DESCRIPTION', '<img src="images/icon_popup.gif" border="0">&nbsp;<a href="https://www.2checkout.com/2co/signup?affiliate=1255821" target="_blank" style="text-decoration: underline; font-weight: bold;">Visita la web de 2Checkout</a>&nbsp;<a href="javascript:toggleDivBlock(\'pm2checkoutInfo\');">(info)</a><span id="pm2checkoutInfo" style="display: none;"><br><i>Con el uso del Link para usar 2Checkout osCommerce dar a cada Cliente nuevo un pequeno Bonus.</i></span><br><br>Tarjeta de Cr&eacute;dito para Pruebas:<br><br>Numero: 4111111111111111<br>Caducidad: Cualquiera');
  define('MODULE_PAYMENT_2CHECKOUT_TEXT_ERROR_MESSAGE', 'Ha ocurrido un error procesando su tarjeta de cr&eacute;dito, por favor int&eacute;ntelo de nuevo.');
  define('MODULE_PAYMENT_2CHECKOUT_TEXT_WARNING_DEMO_MODE', 'In Review: Transaction performed in demo mode.');
  define('MODULE_PAYMENT_2CHECKOUT_TEXT_WARNING_TRANSACTION_ORDER', 'In Review: Transaction total did not match order total.');
?>
