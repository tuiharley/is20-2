<?php
/*
  $Id: products_new.php 1739 2007-12-20 00:52:16Z hpdl $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Novedades');
define('HEADING_TITLE', 'Novedades');

define('TEXT_DATE_ADDED', 'Fecha Alta:');
define('TEXT_MANUFACTURER', 'Fabricante:');
define('TEXT_PRICE', 'Precio:');
?>