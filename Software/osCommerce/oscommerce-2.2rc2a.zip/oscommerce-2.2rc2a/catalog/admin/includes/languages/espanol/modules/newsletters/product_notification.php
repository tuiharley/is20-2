<?php
/*
  $Id: product_notification.php 1739 2007-12-20 00:52:16Z hpdl $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('TEXT_COUNT_CUSTOMERS', 'Clientes que recibir&aacute; el bolet&iacute;n: %s');
define('TEXT_PRODUCTS', 'Productos');
define('TEXT_SELECTED_PRODUCTS', 'Productos Seleccionados');

define('JS_PLEASE_SELECT_PRODUCTS', 'Seleccione algunos productos.');

define('BUTTON_GLOBAL', 'Global');
define('BUTTON_SELECT', '>>>');
define('BUTTON_UNSELECT', '<<<');
define('BUTTON_SUBMIT', 'Enviar');
define('BUTTON_CANCEL', 'Cancelar');
?>