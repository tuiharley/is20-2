<?php
/*
  $Id: packingslip.php 1739 2007-12-20 00:52:16Z hpdl $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('TABLE_HEADING_COMMENTS', 'Kommentar');
define('TABLE_HEADING_PRODUCTS_MODEL', 'Artikel-Nr.');
define('TABLE_HEADING_PRODUCTS', 'Artikel');

define('ENTRY_SOLD_TO', 'Rechnungsanschrift:');
define('ENTRY_SHIP_TO', 'Lieferanschrift:');
define('ENTRY_PAYMENT_METHOD', 'Zahlungsweise:');
?>