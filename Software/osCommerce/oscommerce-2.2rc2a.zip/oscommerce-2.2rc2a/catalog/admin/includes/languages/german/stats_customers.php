<?php
/*
  $Id: stats_customers.php 1739 2007-12-20 00:52:16Z hpdl $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Kunden mit den h&ouml;chsten Ums&auml;tzen');

define('TABLE_HEADING_NUMBER', 'Nr.');
define('TABLE_HEADING_CUSTOMERS', 'Kunde');
define('TABLE_HEADING_TOTAL_PURCHASED', 'Gesamtsumme');
?>