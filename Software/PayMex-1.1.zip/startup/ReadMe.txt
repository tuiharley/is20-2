Paymex Start-Up Account CubeCart Payment Module
Version 1.0

Please extract the following files into the CubeCart root directory. 
The directory structure in the zip should map to the directory structure of CubeCart exactly where upload
is the name of your CubeCart installation directory.

Once this is done you need to setup Paymex as a payment module:
1/
Login to the admin page of CubeCart
2/
Click on Modules/Gateways
3/
Click on the configure button next to the Paymex icon in the list displayed.
4/
After you click configure you will be taken to a page where you can edit the parameters to make Paymex work. A description
of the parameters is given below. Once you have made your changes click the "Edit Config" button.

	* Status = This must be set to True to allow Paymex to be used as a module.
	* Business Id = This is the id of your business given to you by Paymex
	* Payment Description = This is what is the description displayed to the user as to what payment method they are using. 
		90% of the time this is set to Paymex.
	* Default = Set this to true to let CubeCart automatically select Paymex as the default payment method.
	* Test mode? = If this is set to Yes then the payment process will be the same HOWEVER will not be processed.
		This can be used to test the payment process. It is important this is set to NO when the store is to go LIVE.

After setting up the appropriate parameters you should successfully have Paymex as a payment provider!
If you have any problems please email support@paymex.co.nz

The Paymex Team

===============
Version History
===============
Version 1.0:
	Initial Release