<?php
/**
 * @package orderTotal
 * @copyright Copyright 2003-2006 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: ot_gv.php 4975 2006-11-20 22:11:21Z wilt $
 */

class ot_gv {
  var $title, $output, $products_count;

  function ot_gv() {
    global $currencies;
    $this->code = 'ot_gv';
    $this->title = MODULE_ORDER_TOTAL_GV_TITLE;
    $this->header = MODULE_ORDER_TOTAL_GV_HEADER;
    $this->description = MODULE_ORDER_TOTAL_GV_DESCRIPTION;
    $this->user_prompt = MODULE_ORDER_TOTAL_GV_USER_PROMPT;
    $this->sort_order = MODULE_ORDER_TOTAL_GV_SORT_ORDER;
    $this->include_shipping = MODULE_ORDER_TOTAL_GV_INC_SHIPPING;
    $this->include_tax = MODULE_ORDER_TOTAL_GV_INC_TAX;
    $this->calculate_tax = MODULE_ORDER_TOTAL_GV_CALC_TAX;
    $this->credit_tax = MODULE_ORDER_TOTAL_GV_CREDIT_TAX;
    $this->tax_class  = MODULE_ORDER_TOTAL_GV_TAX_CLASS;
    $this->show_redeem_box = MODULE_ORDER_TOTAL_GV_REDEEM_BOX;
    $this->credit_class = true;
    if (!zen_not_null(ltrim($_SESSION['cot_gv'], ' 0')) || $_SESSION['cot_gv'] == '0') $_SESSION['cot_gv'] = '0.00';
    $this->checkbox = $this->user_prompt . '<input type="text" size="6" onchange="submitFunction()" name="cot_gv" value="' . number_format($_SESSION['cot_gv'], 0) . '" onfocus="if (this.value == \'' . number_format($_SESSION['cot_gv'], 0) . '\') this.value = \'\';" />' . ($this->user_has_gv_account($_SESSION['customer_id']) >= 0 ? '<br />' . MODULE_ORDER_TOTAL_GV_USER_BALANCE .   number_format($this->user_has_gv_account($_SESSION['customer_id']),0) : '');
    $this->output = array();
  }

  function process() {
    global $order, $currencies;
    if ($_SESSION['cot_gv']) {
      $order_total = $this->get_order_total();
      $od_amount = $this->calculate_credit($order_total);
	  
      if ($this->calculate_tax != "none") {
        $tod_amount = zen_round($this->calculate_tax_deduction($order_total, $od_amount, $this->calculate_tax, true), 2);
        $od_amount = $this->calculate_credit($order_total);
      }
      $this->deduction = $od_amount + $tod_amount;
      $order->info['total'] = zen_round($order->info['total'] - $this->deduction, 2);
      if ($od_amount > 0) {
            if (DISPLAY_PRICE_WITH_TAX == 'true') {
              $this->deduction += zen_calculate_tax($this->deduction, $tax);
            }

        $this->output[] = array('title' => $this->title .' - You got '. $this->product_count .' product(s) for $0.00:',
                                'text' => '-' . $currencies->format($this->deduction),
                                'value' => $this->deduction);
      }
    }
  }

  function clear_posts() {
    unset($_SESSION['cot_gv']);
  }
  function selection_test() {
    if ($this->user_has_gv_account($_SESSION['customer_id'])) {
      return true;
    } else {
      return false;
    }
  }

  function pre_confirmation_check($order_total) {
    global $order, $currencies;
    // clean out negative values and strip common currency symbols
    $_SESSION['cot_gv'] = preg_replace('/[^0-9.%]/', '', $_SESSION['cot_gv']);
    $_SESSION['cot_gv'] = abs($_SESSION['cot_gv']);

    if ($_SESSION['cot_gv'] > 0) {
      if ($this->include_shipping == 'false') $order_total -= $order->info['shipping_cost'];
      if ($this->include_tax == 'false') $order_total -= $order->info['tax'];
      if (ereg('[^0-9/.]', trim($_SESSION['cot_gv']))) {
        zen_redirect(zen_href_link(FILENAME_CHECKOUT_PAYMENT, 'credit_class_error_code=' . $this->code . '&credit_class_error=' . urlencode(TEXT_INVALID_REDEEM_AMOUNT), 'SSL',true, false));
      }
      if ((int)$_SESSION['cot_gv'] > (int)$this->user_has_gv_account($_SESSION['customer_id'])) {
        zen_redirect(zen_href_link(FILENAME_CHECKOUT_PAYMENT, 'credit_class_error_code=' . $this->code . '&credit_class_error=' . urlencode(TEXT_INVALID_REDEEM_AMOUNT), 'SSL',true, false));
      }
      $od_amount = $this->calculate_credit($order_total);
	  
      if ($this->calculate_tax != "none") {
        $tod_amount = $this->calculate_tax_deduction($order_total, $od_amount, $this->calculate_tax);
        $od_amount = $this->calculate_credit($order_total)+$tod_amount;
      }
      if ($od_amount >= $order->info['total'] && MODULE_ORDER_TOTAL_GV_ORDER_STATUS_ID != 0) $order->info['order_status'] = MODULE_ORDER_TOTAL_GV_ORDER_STATUS_ID;
    }
    return $od_amount + $tod_amount;
  }

  function use_credit_amount() {
    if ($this->selection_test()) {
      $output_string = $this->checkbox;
    }
    return $output_string;
  }

  function update_credit_account($i) {
    global $db, $order, $insert_id, $messageStack;
	
    if (ereg('^PAX-', addslashes($order->products[$i]['model']))) {
	 $gv_order_amount = substr(trim($order->products[$i]['model']),4);
	 if (!is_numeric($gv_order_amount)){
	 		$messageStack->add_session('checkout_payment', MODULE_ORDER_TOTAL_GV_MODEL_ERROR . ':'. $gv_order_amount, error);
        	zen_redirect(zen_href_link(FILENAME_CHECKOUT_PAYMENT, '', 'SSL'));
	} 
	 $gv_order_amount = (int)$gv_order_amount * $order->products[$i]['qty'];
	 
	 if (MODULE_ORDER_TOTAL_GV_QUEUE == 'false') {
				// GV_QUEUE is false so release amount to account immediately
				$gv_result = $this->user_has_gv_account($_SESSION['customer_id']);
				$customer_gv = false;
				$total_gv_amount = 0;
				if ($gv_result) {
				  $total_gv_amount = $gv_result;
				  $customer_gv = true;
				}
				$total_gv_amount = $total_gv_amount + $gv_order_amount;
				if ($customer_gv) {
				  $db->Execute("update " . TABLE_COUPON_GV_CUSTOMER . " set amount = '" . $total_gv_amount . "' where customer_id = '" . (int)$_SESSION['customer_id'] . "'");
				} else {
				  $db->Execute("insert into " . TABLE_COUPON_GV_CUSTOMER . " (customer_id, amount) values ('" . (int)$_SESSION['customer_id'] . "', '" . $total_gv_amount . "')");
				}
      } else {
        // GV_QUEUE is true - so queue the gv for release by store owner
        $db->Execute("insert into " . TABLE_COUPON_GV_QUEUE . " (customer_id, order_id, amount, date_created, ipaddr) values ('" . (int)$_SESSION['customer_id'] . "', '" . (int)$insert_id . "', '" . $gv_order_amount. "', NOW(), '" . $_SERVER['REMOTE_ADDR'] . "')");
	  }
    }
  }

  function credit_selection() {
    global $db, $currencies;
    $gv_query = $db->Execute("select coupon_id from " . TABLE_COUPONS . " where coupon_type = 'G' and coupon_active='Y'");
    if ($gv_query->RecordCount() > 0 || $this->use_credit_amount()) {
      $selection = array('id' => $this->code,
                         'module' => $this->title,
                         'redeem_instructions' => MODULE_ORDER_TOTAL_GV_REDEEM_INSTRUCTIONS,
                         'checkbox' => $this->use_credit_amount(),
                         'fields' => array(array('title' => MODULE_ORDER_TOTAL_GV_TEXT_ENTER_CODE,
                                                 'field' => zen_draw_input_field('gv_redeem_code', '', 'id="disc-'.$this->code.'" onchange="submitFunction(0,0)"'),
                                                 'tag' => 'disc-'.$this->code
                         )));

    }
    return $selection;
  }

  function apply_credit() {
    global $db, $order, $messageStack;
    if ($_SESSION['cot_gv'] != 0) {
      $gv_result = $db->Execute("select amount from " . TABLE_COUPON_GV_CUSTOMER . " where customer_id = '" . (int)$_SESSION['customer_id'] . "'");
    $gv_payment_amount = $this->product_count;
      $gv_amount = $gv_result->fields['amount'] - $gv_payment_amount;
      $db->Execute("update " . TABLE_COUPON_GV_CUSTOMER . " set amount = '" . $gv_amount . "' where customer_id = '" . (int)$_SESSION['customer_id'] . "'");
    }
    $_SESSION['cot_gv'] = false;
    return $gv_payment_amount;
  }


  function collect_posts() {
    global $db, $currencies, $messageStack;
    if (!$_POST['cot_gv']) $_SESSION['cot_gv'] = '0';
    if ($_POST['gv_redeem_code']) {
      $gv_result = $db->Execute("select coupon_id, coupon_type, coupon_amount from " . TABLE_COUPONS . " where coupon_code = '" . zen_db_prepare_input($_POST['gv_redeem_code']) . "'");
      if ($gv_result->RecordCount() > 0) {
        $redeem_query = $db->Execute("select * from " . TABLE_COUPON_REDEEM_TRACK . " where coupon_id = '" . (int)$gv_result->fields['coupon_id'] . "'");
        if ( ($redeem_query->RecordCount() > 0) && ($gv_result->fields['coupon_type'] == 'G')  ) {
          $messageStack->add_session('checkout_payment', ERROR_NO_INVALID_REDEEM_GV, error);
          zen_redirect(zen_href_link(FILENAME_CHECKOUT_PAYMENT, '', 'SSL'));
        }
      } else {
        $messageStack->add_session('checkout_payment', ERROR_NO_INVALID_REDEEM_GV, error);
        zen_redirect(zen_href_link(FILENAME_CHECKOUT_PAYMENT, '', 'SSL'));
      }
      if ($gv_result->fields['coupon_type'] == 'G') {
        $gv_amount = $gv_result->fields['coupon_amount'];
        // Things to set
        // ip address of claimant
        // customer id of claimant
        // date
        // redemption flag
        // now update customer account with gv_amount
        $gv_amount_result=$db->Execute("select amount from " . TABLE_COUPON_GV_CUSTOMER . " where customer_id = '" . (int)$_SESSION['customer_id'] . "'");
        $customer_gv = false;
        $total_gv_amount = $gv_amount;;
        if ($gv_amount_result->RecordCount() > 0) {
          $total_gv_amount = $gv_amount_result->fields['amount'] + $gv_amount;
          $customer_gv = true;
        }
        $db->Execute("update " . TABLE_COUPONS . " set coupon_active = 'N' where coupon_id = '" . $gv_result->fields['coupon_id'] . "'");
        $db->Execute("insert into  " . TABLE_COUPON_REDEEM_TRACK . " (coupon_id, customer_id, redeem_date, redeem_ip) values ('" . $gv_result->fields['coupon_id'] . "', '" . (int)$_SESSION['customer_id'] . "', now(),'" . $_SERVER['REMOTE_ADDR'] . "')");
        if ($customer_gv) {
          // already has gv_amount so update
          $db->Execute("update " . TABLE_COUPON_GV_CUSTOMER . " set amount = '" . $total_gv_amount . "' where customer_id = '" . (int)$_SESSION['customer_id'] . "'");
        } else {
          // no gv_amount so insert
          $db->Execute("insert into " . TABLE_COUPON_GV_CUSTOMER . " (customer_id, amount) values ('" . (int)$_SESSION['customer_id'] . "', '" . $total_gv_amount . "')");
        }
        //          zen_redirect(zen_href_link(FILENAME_CHECKOUT_PAYMENT, 'error_message=' . urlencode(ERROR_REDEEMED_AMOUNT. $currencies->format($gv_amount)), 'SSL'));
        $messageStack->add_session('redemptions',ERROR_REDEEMED_AMOUNT. number_format($gv_amount,0), 'success' );
      }
    }
    if ($_POST['submit_redeem_x'] && $gv_result->fields['coupon_type'] == 'G') zen_redirect(zen_href_link(FILENAME_CHECKOUT_PAYMENT, 'error_message=' . urlencode(ERROR_NO_REDEEM_CODE), 'SSL'));
  }

  function calculate_credit($amount) {
    global $db, $order, $currencies;

    $gv_payment_amount = (int) $_SESSION['cot_gv'];
    $gv_amount = $gv_payment_amount;
    $save_total_cost = $amount;
	$product_count =0;
    
	for ($i=0, $n=sizeof($order->products); $i<$n; $i++) {
		//skip if the product is a giftvoucher or products is in restricted list
		if ( $this->_is_valid_product($order->products[$i]['id'],$order->products[$i]['model'])) {
				for($i2=1; $i2<=$order->products[$i]['qty'];$i2++) {
							$product_count += 1;
							if ($product_count <= (int)$gv_payment_amount){
								$gv_payment_amount_in_dollars += $order->products[$i]['final_price'];
							}
							
				}
		}// end if
	}
	$this->product_count = $product_count;
	
	$full_cost = $save_total_cost - $gv_payment_amount_in_dollars;
    
	
	
	if ($full_cost < 0) {
      $full_cost = 0;
      $gv_payment_amount_in_dollars = $save_total_cost;
    }
	return zen_round($gv_payment_amount_in_dollars,2);
  }
function _is_valid_product($productid=0, $product_model='' ) {
	global $db;
	/*check to see if product is a gift, if so exclude*/
	if (ereg('^PAX-', $product_model)) {
      return false;
    }
	/* check if product is on the exclusion list */
	$query ="select * from ". DB_PREFIX . "gv_exclusion_list where productid='".$productid."'";
	$results = $db->Execute($query);
	if ($results->RecordCount() >= 1) return false;
	
	/* check to see if product is in a excluded category id */
	$query ="select categories_id from ". DB_PREFIX . "products_to_categories where products_id='".$productid."'";
	$results = $db->Execute($query);
	while (!$results->EOF) {
		  $query2="select * from ". DB_PREFIX . "gv_exclusion_list where categoryid='".$results->fields['categories_id'] ."'";
		  $results2 = $db->Execute($query2);
		  if ($results2->RecordCount >= 1) return false;
		 $results->MoveNext();
		 }
		
	return true;
}
  function calculate_tax_deduction($amount, $od_amount, $method, $finalise = false) {
    global $order;
    $tax_address = zen_get_tax_locations();
    switch ($method) {
      case 'Standard':
      $ratio1 = zen_round($od_amount / $amount,2);
      $tod_amount = 0;
      reset($order->info['tax_groups']);
      while (list($key, $value) = each($order->info['tax_groups'])) {
        $tax_rate = zen_get_tax_rate_from_desc($key, $tax_address['country_id'], $tax_address['zone_id']);
        $total_net += $tax_rate * $value;
      }
      if ($od_amount > $total_net) $od_amount = $total_net;
      reset($order->info['tax_groups']);
      while (list($key, $value) = each($order->info['tax_groups'])) {
        $tax_rate = zen_get_tax_rate_from_desc($key, $tax_address['country_id'], $tax_address['zone_id']);
        $net = $tax_rate * $value;
        if ($net > 0) {
          $god_amount = $value * $ratio1;
          $tod_amount += $god_amount;
          if ($finalise) $order->info['tax_groups'][$key] = $order->info['tax_groups'][$key] - $god_amount;
        }
      }
      if ($finalise) $order->info['tax'] -= $tod_amount;
      if ($finalise) $order->info['total'] -= $tod_amount;
      break;
      case 'Credit Note':
      $tax_rate = zen_get_tax_rate($this->tax_class, $tax_address['country_id'], $tax_address['zone_id']);
      $tax_desc = zen_get_tax_description($this->tax_class, $tax_address['country_id'], $tax_address['zone_id']);
      $tod_amount = $this->deduction / (100 + $tax_rate)* $tax_rate;
      if ($finalise) $order->info['tax_groups'][$tax_desc] -= $tod_amount;
      if ($finalise) $order->info['tax'] -= $tod_amount;
      if ($finalise) $order->info['total'] -= $tod_amount;
      break;
      default:
    }
    return $tod_amount;
  }

  function user_has_gv_account($c_id) {
    global $db;
    $gv_result = $db->Execute("select amount from " . TABLE_COUPON_GV_CUSTOMER . " where customer_id = '" . (int)$c_id . "'");
    if ($gv_result->RecordCount() > 0) {
      return $gv_result->fields['amount'];
    }
    //      return false;
    return 0; // was preventing checkout_payment from continuing
  }

  function get_order_total() {
    global $order;
    $order_total = $order->info['total'];
    if ($this->include_tax == 'false') $order_total = $order_total - $order->info['tax'];
    if ($this->include_shipping == 'false') $order_total = $order_total - $order->info['shipping_cost'];

    return $order_total;
  }

  function check() {
    global $db;
    if (!isset($this->check)) {
      $check_query = $db->Execute("select configuration_value from " . TABLE_CONFIGURATION . " where configuration_key = 'MODULE_ORDER_TOTAL_GV_STATUS'");
      $this->check = $check_query->RecordCount();
    }

    return $this->check;
  }

  function keys() {
    return array('MODULE_ORDER_TOTAL_GV_STATUS', 'MODULE_ORDER_TOTAL_GV_SORT_ORDER', 'MODULE_ORDER_TOTAL_GV_QUEUE', 'MODULE_ORDER_TOTAL_GV_INC_SHIPPING', 'MODULE_ORDER_TOTAL_GV_INC_TAX', 'MODULE_ORDER_TOTAL_GV_CALC_TAX', 'MODULE_ORDER_TOTAL_GV_TAX_CLASS', 'MODULE_ORDER_TOTAL_GV_CREDIT_TAX',  'MODULE_ORDER_TOTAL_GV_ORDER_STATUS_ID');
  }

  function install() {
    global $db;
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) values ('This module is installed', 'MODULE_ORDER_TOTAL_GV_STATUS', 'true', '', '6', '1','zen_cfg_select_option(array(\'true\'), ', now())");
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('Sort Order', 'MODULE_ORDER_TOTAL_GV_SORT_ORDER', '840', 'Sort order of display.', '6', '2', now())");
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) values ('Queue Purchases', 'MODULE_ORDER_TOTAL_GV_QUEUE', 'true', 'Do you want to queue purchases of the Gift Voucher?', '6', '3','zen_cfg_select_option(array(\'true\', \'false\'), ', now())");
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function ,date_added) values ('Include Shipping', 'MODULE_ORDER_TOTAL_GV_INC_SHIPPING', 'true', 'Include Shipping in calculation', '6', '5', 'zen_cfg_select_option(array(\'true\', \'false\'), ', now())");
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function ,date_added) values ('Include Tax', 'MODULE_ORDER_TOTAL_GV_INC_TAX', 'false', 'Include Tax in calculation.', '6', '6','zen_cfg_select_option(array(\'true\', \'false\'), ', now())");
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function ,date_added) values ('Re-calculate Tax', 'MODULE_ORDER_TOTAL_GV_CALC_TAX', 'None', 'Re-Calculate Tax', '6', '7','zen_cfg_select_option(array(\'None\', \'Standard\', \'Credit Note\'), ', now())");
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, use_function, set_function, date_added) values ('Tax Class', 'MODULE_ORDER_TOTAL_GV_TAX_CLASS', '0', 'Use the following tax class when treating Gift Voucher as Credit Note.', '6', '0', 'zen_get_tax_class_title', 'zen_cfg_pull_down_tax_classes(', now())");
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function ,date_added) values ('Credit including Tax', 'MODULE_ORDER_TOTAL_GV_CREDIT_TAX', 'false', 'Add tax to purchased Gift Voucher when crediting to Account', '6', '8','zen_cfg_select_option(array(\'true\', \'false\'), ', now())");
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, use_function, date_added) values ('Set Order Status', 'MODULE_ORDER_TOTAL_GV_ORDER_STATUS_ID', '0', 'Set the status of orders made where GV covers full payment', '6', '0', 'zen_cfg_pull_down_order_statuses(', 'zen_get_order_status_name', now())");
  	if (!mysql_query("select * from ". DB_PREFIX . "gv_exclusion_list limit 1")){
			$db->Execute("CREATE TABLE `". DB_PREFIX . "gv_exclusion_list` (
		  `gv_exclusion_id` INTEGER UNSIGNED NOT NULL AUTO_INCREMENT,
		  `productid` INTEGER UNSIGNED DEFAULT 0,
		  `categoryid` INTEGER UNSIGNED DEFAULT 0,
		  PRIMARY KEY(`gv_exclusion_id`),
		  INDEX `idx_productid`(`productid`),
		  INDEX `idx_categoryid`(`categoryid`))");
	}
  
  }

  function remove() {
    global $db;
    $db->Execute("delete from " . TABLE_CONFIGURATION . " where configuration_key in ('" . implode("', '", $this->keys()) . "')");
  }
}
?>
