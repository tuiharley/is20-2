DROP TABLE orders_invoices;

