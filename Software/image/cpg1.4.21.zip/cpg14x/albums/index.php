<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Coppermine Photo Gallery - Albums Folder</title>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="refresh" content="0; url=../index.php">
<style type="text/css">
<!--
body {
        font-family : Verdana, Arial, Helvetica, sans-serif;
        font-size: 12px;
        background : #F7F7F7 ;
        color : Black;
        margin: 20px;
}

h1{
        font-weight: bold;
        font-size: 22px;
        font-family: "Trebuchet MS", Verdana, Arial, Helvetica, sans-serif;
        text-decoration: none;
        line-height : 120%;
        color : #000000;
}

p {
        font-family : Verdana, Arial, Helvetica, sans-serif;
        font-size: 12px;
        margin: 10px 10px 0px 0px;
}

-->
</style>
</head>
<body>
<h1><img src="../images/coppermine_logo.png" width="300" height="75" /></h1>
<h1>Coppermine Photo Gallery - Albums Folder</h1>
<p align="center">The contents of this folder aren't meant to be browsed. Visit the Coppermine Photo Gallery instead - you'll be redirected.
If you don't want to wait (or your browser doesn't support redirect), click <a href="../index.php">here</a>.</p>

</body>
</html>