<?php
/*
+--------------------------------------------------------------------------
|   CubeCart v3.0.3
|   ========================================
|   by Alistair Brookbanks
|	CubeCart is a Trade Mark of Devellion Limited
|   (c) 2005 Devellion Limited
|   Devellion Limited,
|   Westfield Lodge,
|   Westland Green,
|   Little Hadham,
|   Nr Ware, HERTS.
|   SG11 2AL
|   UNITED KINGDOM
|   http://www.devellion.com
|	UK Private Limited Company No. 5323904
|   ========================================
|   Web: http://www.cubecart.com
|   Date: Thursday, 25 August 2005
|   Email: info (at) cubecart (dot) com
|	License Type: CubeCart is NOT Open Source Software and Limitations Apply 
|   Licence Info: http://www.cubecart.com/site/faq/license.php
+--------------------------------------------------------------------------
|	editconf.php
|   ========================================
|	Config recovery tool	
+--------------------------------------------------------------------------
*/
if(!isset($_GET['c'])){
	header("Location: editconf.php?c=config");
	exit;
}
include_once("includes/ini.inc.php");
include_once("includes/global.inc.php");
include_once("classes/db.inc.php");
$db = new db();
include_once("includes/functions.inc.php");
include_once("admin/includes/functions.inc.php");

if(isset($_POST['data'])){
	//$config = fetchDbConfig($_GET['c']);
	$msg = writeDbConf($_POST['data'],$_GET['c'], $config, $_GET['c']);
}

$config = fetchDbConfig($_GET['c']);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>CubeCart - Config Recovery Tool</title>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}
//-->
</script>
<style type="text/css">
<!--
body,td,th {
	font-family: Verdana, Arial, Helvetica, sans-serif;
}
.code {
	font-family: "Courier New", Courier, mono;
	color: #000000;
}
.redText {color: #FF0000}
-->
</style></head>

<body>
<span class="redText"><?php if(isset($msg)) { echo $msg; } ?></span>
<h1>Config Recovery Tool</h1>
<p><strong>Devellion Ltd &amp; CubeCart provide this script without any warranty of any kind and by proceeding you are doing so entirely at your own risk.</strong></p>
<p>This tool is designed to edit your config file if for some reason your store becomes corrupt due to incorrectly changing your settings.</p>
<p>Example: If you have switched on SSL mode and your store has become broken. Select &quot;config&quot; from the dropdown menu below and set
$config['ssl']
to 0. No test to see if your store has been fixed and if so delete this file from the server. </p>
<p class="redText"><strong>IMPORTANT:</strong> You must NOT leave this file on your server as it is a VERY high security risk!</p>
<p><a href="index.php" target="_blank">View Store Front</a> - (Opens in New Window)<br />
  <a href="admin/" target="_blank">View Store Admin</a> - (Opens in New Window)</p>
<p>Select Config to edit: 
<?php
$query = "SELECT * FROM ".$glob['dbprefix']."CubeCart_config";
$results = $db->select($query);
?>
  <select name="menu1" onchange="MM_jumpMenu('parent',this,0)">
    <?php for ($i=0; $i<count($results); $i++){ ?>
	<option value="?c=<?php echo $results[$i]['name']; ?>" <?php if($_GET['c']==$results[$i]['name']) { echo "selected=\"selected\""; } ?>><?php echo $results[$i]['name']; ?></option>
	<?php } ?>
  </select>
</p>
<form name="form1" id="form1" method="post" action="editconf.php?c=<?php echo $_GET['c']; ?>">
<table border="1" cellspacing="0" cellpadding="2">
  <tr>
    <td><strong>Variable name: </strong></td>
    <td><strong>Current Value: </strong></td>
    <td><strong>New Value: </strong></td>
  </tr>
  <?php foreach($config as $key => $value) { ?>
  <tr>
    <td class="code"><?php echo "\$".$_GET['c']."['".$key."']"; ?></td>
    <td class="code"><?php echo $value; ?></td>
    <td>
      <textarea name="data[<?php echo $key; ?>]" cols="30" rows="2"><?php echo $value; ?></textarea>
    </td>
  </tr>
  <?php } ?>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td><input type="submit" name="Submit" value="Update Config" /></td>
  </tr>
</table>
</form>
</body>
</html>
