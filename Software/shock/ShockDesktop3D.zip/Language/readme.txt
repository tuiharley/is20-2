[Supported languages] - http://www.docs.kr

  --------------------------------------------------------
   Language                     File Name
  --------------------------------------------------------
   Korea                        Korea.dat
   Arabic                       Arabic.dat
   Brazil                       Brazil.dat
   Chinese(Simplified)          Chinese(Simplified).dat
   Chinese(Traditional)         Chinese(Traditional).dat
   Czech                        Czech.dat
   Danish                       Danish.dat
   Dutch                        Dutch.dat
   English                      English.dat
   Finnish                      Finnish.dat
   French                       French.dat
   German                       German.dat
   Greek                        Greek.dat
   Hebrew                       Hebrew.dat
   Hungarian                    Hungarian.dat
   Italian                      Italian.dat
   Japanese                     Japanese.dat
   Norwegian                    Norwegian.dat
   Polish                       Polish.dat
   Portuguese                   Portuguese.dat
   Russian                      Russian.dat
   Slovak                       Slovak.dat
   Slovenian                    Slovenian.dat
   Spanish                      Spanish.dat
   Swedish                      Swedish.dat
   Turkish                      Turkish.dat
  --------------------------------------------------------

* Please send me a new file is created.
* shockutility@gmail.com


