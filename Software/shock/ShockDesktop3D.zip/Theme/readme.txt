[How to create a theme] - http://theme.docs.kr

  -----------------------------------------------
   Type 1 - [1 image]
  -----------------------------------------------  
  [All]
  Image=all.bmp
  XTileCount=1
  YTileCount=1
  -----------------------------------------------  


  -----------------------------------------------
   Type 2 - [2 images]
  -----------------------------------------------  
  [Bottom]
  Image=bottom.bmp

  [Other]
  Skin=other.bmp
  -----------------------------------------------


  -----------------------------------------------
   Type 3 - [4 images]
  -----------------------------------------------  
  [Bottom]
  Image=bottom.bmp

  [Left]
  Image=left.bmp

  [Right]
  Image=right.bmp

  [Back]
  Image=back.bmp
  -----------------------------------------------


  -----------------------------------------------
   Type 4 - [Tile]
  -----------------------------------------------
  [Bottom]
  Image=bottom.bmp
  XTileCount=5
  YTileCount=5

  [Other]
  Image=other.bmp
  XTileCount=5
  YTileCount=5
  -----------------------------------------------


* Please send me a new theme is created.
* shockutility@gmail.com


