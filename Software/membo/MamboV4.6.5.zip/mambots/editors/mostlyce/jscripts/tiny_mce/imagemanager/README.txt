This is a stand alone Image Manager + Editor

The PHP ImageManager + Editor provides an interface to 
browser for image files on your web server. The Editor
allows some basic image manipulations such as, cropping,
rotation, flip, and scaling.

Further and up-to-date documentation can be found at
http://www.zhuo.org/htmlarea/docs/index.html

Cheer,
Wei