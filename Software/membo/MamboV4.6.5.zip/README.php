<?php
/**
* Readme File
* @package Mambo
* @author Mambo Foundation Inc see README.php
* @copyright Mambo Foundation Inc.
* See COPYRIGHT.php for copyright notices and details.
* @license GNU/GPL Version 2, see LICENSE.php
* Mambo is free software; you can redistribute it and/or
* modify it under the terms of the GNU General Public License
* as published by the Free Software Foundation; version 2 of the License.
*/

?> 

Mambo is OSI Certified Open Source Software, released under the GNU General Public License (GPL) Version 2.
OSI Certified is a certification mark of the Open Source Initiative. Mambo is free to use and to modify under the terms of the GNU General Public License. For more detailed information on Mambo's licensing terms see the LICENSE file.

The Mambo name and logo are registered trademarks of the Mambo Foundation, Inc in Australia and other countries.
For more information about the Mambo Foundation, please visit http://mambo-foundation.org.

Mambo was originally developed by Miro International Pty Ltd in 2000. Mambo became Open Source software in April, 2001 under the GNU/GPL license. Miro assigned the copyright in Mambo to The Mambo Foundation in 2005 to ensure that Mambo remained free Open Source software owned and managed by the community.

For detailed information about installing Mambo see INSTALL.php. Help is available on the Mambo peer-support forums at http://forum.mambo-foundation.org and in the Mambo documentation at http://mambo-support.org.

NOTE: Mambo is FREE to download and to use. For your own safety, please ensure that you have downloaded Mambo from a reputable source. The official Mambo download repository is at http://mambo-code.org.