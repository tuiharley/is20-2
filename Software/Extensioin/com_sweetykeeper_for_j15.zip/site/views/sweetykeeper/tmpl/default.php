<?php // no direct access
defined('_JEXEC') or die('Restricted access'); ?>
<h1>Sweety Keeper Component</h1>
		<table align="center">
	 	 <tr>
		   <td>
			<OBJECT classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"
			 codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0"
			 WIDTH="500" HEIGHT="400" id="sweetykeeper" ALIGN="">
			 <PARAM NAME=movie VALUE="components/com_sweetykeeper/views/sweetykeeper/<?php echo $this->greeting; ?>">
			 <PARAM NAME=quality VALUE=high>
			 <PARAM NAME=bgcolor VALUE="#ffffff">
			 <EMBED src="components/com_sweetykeeper/views/sweetykeeper/<?php echo $this->greeting; ?>" quality=high bgcolor="#ffffff" WIDTH="500" HEIGHT="400"  ALIGN=""
			 TYPE="application/x-shockwave-flash" PLUGINSPAGE="http://www.macromedia.com/go/getflashplayer"></EMBED>
			</OBJECT>
			<br>
			<br>
			<center>
			Games by <b><img src='components/com_sweetykeeper/views/sweetykeeper/magcartoon.png'><a href="http://www.magcartoon.com/" target="_blank">  Magcartoon.com</a></b> - Component By : <a href="http://www.mambohub.com" target="_blank"><img src='components/com_sweetykeeper/views/sweetykeeper/mambohub.png' alt='http://www.mambohub.com' border='0'></a></center>
		   </td>
		 </tr>
		</table>