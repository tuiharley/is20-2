<?php

jimport( 'joomla.application.component.view');

/**
 * HTML View class for the Sweety Keeper Component
 *
 * @package		Joomla.Tutorials

 * @subpackage	Components
 */
class SweetyKeeperViewSweetyKeeper extends JView
{
	function display($tpl = null)
	{
		$greeting = $this->get( 'Greeting' );
		$this->assignRef( 'greeting',	$greeting );

		parent::display($tpl);
	}
}
?>
