<?php
/*
+--------------------------------------------------------------------------
|   CubeCart v3.0.12
|   ========================================
|   by Alistair Brookbanks
|	CubeCart is a Trade Mark of Devellion Limited
|   Copyright Devellion Limited 2005 - 2006. All rights reserved.
|   Devellion Limited,
|   22 Thomas Heskin Court,
|   Station Road,
|   Bishops Stortford,
|   HERTFORDSHIRE.
|   CM23 3EE
|   UNITED KINGDOM
|   http://www.devellion.com
|	UK Private Limited Company No. 5323904
|   ========================================
|   Web: http://www.cubecart.com
|   Date: Thursday, 17th August 2006
|   Email: sales (at) cubecart (dot) com
|	License Type: CubeCart is NOT Open Source Software and Limitations Apply 
|   Licence Info: http://www.cubecart.com/site/faq/license.php
+--------------------------------------------------------------------------
|	confirmed.php
|   ========================================
|	Order Confirmation
+--------------------------------------------------------------------------
*/
	if(!isset($_GET['cartId']) && !isset($_GET['transactionnumber'])){
		echo 'failed';
		exit;
	}

	include_once("../../../includes/ini.inc.php");
	
	// INCLUDE CORE VARIABLES & FUNCTIONS
	include_once("../../../includes/global.inc.php");
	$enableSSl = 1;
	
	// initiate db class
	include_once("../../../classes/db.inc.php");
	$db = new db();
	
	include_once("../../../includes/functions.inc.php");
	$config = fetchDbConfig("config");
	
	include_once("../../../includes/sslSwitch.inc.php");
	
	include_once("../../../includes/session.inc.php");
	// get exchange rates etc
	include_once("../../../includes/currencyVars.inc.php");
	
	include_once("../../../language/".$config['defaultLang']."/lang.inc.php");

	// WORK OUT IS THE ORDER WAS SUCCESSFULL OR NOT ;)

	// 1. Include gateway file

	include("transfer.inc.php");

	// 2. Include function which returns ture or false

	$success = successFirst();
	    
	if($success == TRUE){	
		
		$cart_order_id = $_GET['cartId'];
		
        // add affilate tracking code/module
        $affiliateModule = $db->select("SELECT folder, `default` FROM ".$glob['dbprefix']."CubeCart_Modules WHERE module='affiliate' AND status = 1");

        if($affiliateModule == TRUE) {
	
            for($i=0; $i<count($affiliateModule); $i++){
			
                include("../../../modules/affiliate/".$affiliateModule[$i]['folder']."/tracker.inc.php");
                // VARS AVAILABLE
                // Order Id Number $basket['cart_order_id']
                // Order Total $order[0]['prod_total']
                $basket['cart_order_id'] = $cart_order_id;
                $order[0]['prod_total'] = $_GET['transactionamount'];
			}
		}
		
		//Update order status
		include_once("../../../includes/orderSuccess.inc.php");
		
		echo 'success';
	} 

?>
</body>
</html>
