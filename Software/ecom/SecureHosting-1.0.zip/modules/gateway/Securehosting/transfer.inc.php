<?php
/*
+--------------------------------------------------------------------------
|   CubeCart v3.0.12
|   ========================================
|   by Alistair Brookbanks
|	CubeCart is a Trade Mark of Devellion Limited
|   Copyright Devellion Limited 2005 - 2006. All rights reserved.
|   Devellion Limited,
|   22 Thomas Heskin Court,
|   Station Road,
|   Bishops Stortford,
|   HERTFORDSHIRE.
|   CM23 3EE
|   UNITED KINGDOM
|   http://www.devellion.com
|	UK Private Limited Company No. 5323904
|   ========================================
|   Web: http://www.cubecart.com
|   Date: Thursday, 17th August 2006
|   Email: sales (at) cubecart (dot) com
|	License Type: CubeCart is NOT Open Source Software and Limitations Apply 
|   Licence Info: http://www.cubecart.com/site/faq/license.php
+--------------------------------------------------------------------------
|	transfer.php
|   ========================================
|	Core functions for the Securehosting Gateway	
+--------------------------------------------------------------------------
*/
/*
//////////////////////////
// SECUREHOSTING GATEWAY
//////////////////////////
// L@@K AT ALL THE LOVELY 
// VARIABLES WE HAVE TO
// PLAY WITH!!
//////

//////////////////////////
// IN THE REPEATED REGION
//////
$orderInv['productId']						- product id as an integer
$orderInv['name']							- product name as a varchar
$orderInv['price']							- price of each product (inc options)
$orderInv['quantity']						- quantity of products as an integer
$orderInv['product_options']				- products attributes as test
$orderInv['productCode']					- product code as a varchar
$i											- This is the current incremented integer starting at 0

/////////////////////////
// FIXED VARS
////////////////////////
$cart_order_id								- cart order id as a varchar
$ccUserData[0]['email']						- Customers email address
$ccUserData[0]['title']						- Customers title (Mr Miss etc...)
$ccUserData[0]['firstName']					- Customers first name
$ccUserData[0]['lastName']					- Customers last name 
$ccUserData[0]['add_1']						- Invoice Address line 1
$ccUserData[0]['add_2']						- Invoice Address line 1
$ccUserData[0]['town']						- Invoice Town or city
$ccUserData[0]['county']					- Invoice County or state
$ccUserData[0]['postcode']					- Invoice Post/Zip Code
$ccUserData[0]['country']					- Invoice country Id we can look up the country name like this
										countryName($ccUserData[0]['country']);
$ccUserData[0]['phone']						- Contact phone no
$ccUserData[0]['mobile']					- Mobile/Cell phone number

$basket['delInf']['title']				- Delivery title (Mr Miss etc...)
$basket['delInf']['firstName']			- Delivery customers first name
$basket['delInf']['lastName']			- Delivery customers last name 
$basket['delInf']['add_1']				- Delivery Address line 1
$basket['delInf']['add_2']				- Delivery Address line 1
$basket['delInf']['town']				- Delivery Town or city
$basket['delInf']['county']				- Delivery County or state
$basket['delInf']['postcode']			- Delivery Post/Zip Code
$basket['delInf']['country']			- Delivery  country Id we can look up the country name like this	
									countryName($basket['delInf']['country']);


$basket['subTotal'] 					- Order Subtotal (exTax and Shipping)
$basket['grandTotal']					- Basket total which has to be paid (inc Tax and Shipping).
$basket['tax']							- Total tax to pay
$basket['shipCost']						- Shipping price
////////////////////////////////////////////////////////
*/

$module = fetchDbConfig("Securehosting");
$secuitems="";

function repeatVars(){

        global $orderInv;
        global $secuitems;
        
		$secuitems = $secuitems."[".$orderInv['productCode']."|";
		$secuitems = $secuitems."|".$orderInv['name'];
		
		if ($orderInv['product_options'] != "") {
		    $secuitems =$secuitems." (".$orderInv['product_options'].")";
		}
		
		$price = round($orderInv['price'] / $orderInv['quantity'],2);
		
		$secuitems = $secuitems."|".number_format($price,2)."|"; 
		$secuitems = $secuitems.$orderInv['quantity']."|";
        
        $secuitems = $secuitems.$orderInv['price']."]";

		return false;
}

function fixedVars(){
	
	global $module, $basket, $ccUserData, $cart_order_id, $config, $GLOBALS, $secuitems;
		
	$hiddenVars = "<input type='hidden' name='shreference' value='".$module['shref']."' />
	               <input type='hidden' name='checkcode' value='".$module['ccode']."' />
	               <input type='hidden' name='filename' value='".$module['shref']."/".$module['fname']."' />
				   <input type='hidden' name='cartId' value='".$cart_order_id."' />
				   <input type='hidden' name='secuitems' value='".$secuitems."' />
				   <input type='hidden' name='callbackurl' value='".$GLOBALS['storeURL']."/modules/gateway/Securehosting/confirmed.php' />
				   <input type='hidden' name='callbackdata' value='cartId|".$cart_order_id."|transactionamount|".$basket['grandTotal']."' />
				   <input type='hidden' name='products_price' value='".$basket['subTotal']."' />
				   <input type='hidden' name='transactionamount' value='".$basket['grandTotal']."' />
				   <input type='hidden' name='transactiontax' value='".$basket['tax']."' />
				   <input type='hidden' name='shippingcharge' value='".$basket['shipCost']."' />
				   <input type='hidden' name='transactioncurrency' value='".$config['defaultCurrency']."' />
				   <input type='hidden' name='cardholdersname' value='".$ccUserData[0]['title']." ".$ccUserData[0]['firstName']." ".$ccUserData[0]['lastName']."' />
				   <input type='hidden' name='cardholderaddr1' value='".$ccUserData[0]['add_1']."' />
				   <input type='hidden' name='cardholderaddr2' value='".$ccUserData[0]['add_2']."' />
				   <input type='hidden' name='cardholdercity' value='".$ccUserData[0]['town']."' />
				   <input type='hidden' name='cardholderstate' value='".$ccUserData[0]['county']."' />
				   <input type='hidden' name='cardholderpostcode' value='".$ccUserData[0]['postcode']."' />
				   <input type='hidden' name='cardholdercountry' value='".$ccUserData[0]['country']."' />
				   <input type='hidden' name='cardholdertelephonenumber' value='".$ccUserData[0]['phone']."' />
				   <input type='hidden' name='cardholdersemail' value='".$ccUserData[0]['email']."' />";
				
			return $hiddenVars;
	
}

function successFirst(){
	
	if(isset($_GET['cartId']) && $_GET['transactionnumber']!="-1"){
		return TRUE;
	} else {
		return FALSE;
	}
}

///////////////////////////
// Other Vars
////////
$formAction = "https://www.secure-server-hosting.com/secutran/secuitems.php";
$formMethod = "post";
$formTarget = "_self";
$transfer = "auto";
$stateUpdate = TRUE;
?>