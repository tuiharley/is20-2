Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents DataGrid1 As System.Windows.Forms.DataGrid
    Friend WithEvents Txt_Path As System.Windows.Forms.TextBox
    Friend WithEvents Btn_Browse As System.Windows.Forms.Button
    Friend WithEvents Btn_Import As System.Windows.Forms.Button
    Friend WithEvents Opn As System.Windows.Forms.OpenFileDialog
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.DataGrid1 = New System.Windows.Forms.DataGrid
        Me.Txt_Path = New System.Windows.Forms.TextBox
        Me.Btn_Browse = New System.Windows.Forms.Button
        Me.Btn_Import = New System.Windows.Forms.Button
        Me.Opn = New System.Windows.Forms.OpenFileDialog
        CType(Me.DataGrid1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DataGrid1
        '
        Me.DataGrid1.DataMember = ""
        Me.DataGrid1.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.DataGrid1.Location = New System.Drawing.Point(8, 40)
        Me.DataGrid1.Name = "DataGrid1"
        Me.DataGrid1.ReadOnly = True
        Me.DataGrid1.Size = New System.Drawing.Size(736, 264)
        Me.DataGrid1.TabIndex = 0
        '
        'Txt_Path
        '
        Me.Txt_Path.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Path.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Path.Location = New System.Drawing.Point(192, 8)
        Me.Txt_Path.Name = "Txt_Path"
        Me.Txt_Path.ReadOnly = True
        Me.Txt_Path.Size = New System.Drawing.Size(200, 20)
        Me.Txt_Path.TabIndex = 1
        Me.Txt_Path.Text = ""
        '
        'Btn_Browse
        '
        Me.Btn_Browse.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Browse.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Browse.Location = New System.Drawing.Point(416, 8)
        Me.Btn_Browse.Name = "Btn_Browse"
        Me.Btn_Browse.TabIndex = 2
        Me.Btn_Browse.Text = "Browse"
        '
        'Btn_Import
        '
        Me.Btn_Import.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Import.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Import.Location = New System.Drawing.Point(504, 8)
        Me.Btn_Import.Name = "Btn_Import"
        Me.Btn_Import.TabIndex = 3
        Me.Btn_Import.Text = "Import"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(760, 333)
        Me.Controls.Add(Me.Btn_Import)
        Me.Controls.Add(Me.Btn_Browse)
        Me.Controls.Add(Me.Txt_Path)
        Me.Controls.Add(Me.DataGrid1)
        Me.Name = "Form1"
        Me.Text = "Excel Connectivity"
        CType(Me.DataGrid1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Btn_Browse_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Browse.Click
        Try
            Opn.Filter = "Excel Files (*.xls)|*.xls"
            Opn.ShowDialog()
            Txt_Path.Text = Opn.FileName
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Import_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Import.Click
        Try
            Dim _Obj As New ExcelConnection.ExcelConnection
            _Obj.ImportAttendence(Txt_Path.Text, DataGrid1)
        Catch ex As Exception

        End Try
    End Sub
End Class
